/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import { Complaint, UserProfile, LeaderboardEntry, WalletData, QuizQuestion, Hotspot, PredictionData, AIResult, WasteType } from './src/types';

dotenv.config();

const app = express();
const PORT = 3000;

// Increase payload limits for base64 uploads (photos/voices)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Setup Gemini SDK if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    console.log('Gemini GenAI SDK initialized successfully.');
  } catch (err) {
    console.error('Error initializing Gemini SDK:', err);
  }
} else {
  console.log('Gemini API key not found or using default. Running in mock AI mode.');
}

// ==========================================
// IN-MEMORY DATA STORAGE (Mock Firebase Collections)
// ==========================================

const users: UserProfile[] = [
  {
    id: 'citizen-1',
    name: 'Rahul Sharma',
    email: 'rahul@citizen.com',
    phone: '+91 98765 43210',
    role: 'citizen',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    rewardPoints: 450,
    complaintsCount: 6,
    level: 3,
    achievements: ['Eco Pioneer', 'First Cleanup', 'Waste Warrior'],
  },
  {
    id: 'employee-1',
    name: 'Amit Patel',
    email: 'amit@cleanup.com',
    phone: '+91 87654 32109',
    role: 'employee',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80',
    rewardPoints: 2200, // Performance Score/Points
    complaintsCount: 14, // Tasks Completed
    level: 5,
    achievements: ['Speed Demon', 'Perfect Cleaner', 'Leaderboard Star'],
  },
  {
    id: 'admin-1',
    name: 'Municipal Commissioner',
    email: 'admin@municipal.gov',
    phone: '+91 76543 21098',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
    rewardPoints: 0,
    complaintsCount: 0,
    level: 1,
    achievements: [],
  },
];

// Initial complaints near New Delhi
let complaints: Complaint[] = [
  {
    id: 'comp-101',
    citizenId: 'citizen-1',
    citizenName: 'Rahul Sharma',
    image: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=800&q=80', // Plastic waste pile
    textComplaint: 'Huge pile of plastic wrappers and plastic bottles near the entry of Central Park.',
    voiceComplaint: 'Central park ke entry gate ke pass bahot saara plastic kachra jama ho gaya hai, please ise saf karwayiye.',
    location: {
      lat: 28.6139,
      lng: 77.2090,
      address: 'Central Park Entrance, Connaught Place',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110001',
    },
    timestamp: new Date(Date.now() - 3 * 3600000).toISOString(), // 3 hours ago
    aiResult: {
      wasteType: 'plastic',
      confidence: 0.94,
      area: '2.5 sq meters',
      quantity: 'Approx. 45-50 plastic items',
      density: 'high',
      boxes: [
        { label: 'Plastic Bottle', confidence: 0.96, x: 20, y: 35, w: 15, h: 25 },
        { label: 'Plastic Bag', confidence: 0.92, x: 40, y: 50, w: 25, h: 20 },
        { label: 'Wrapper Heap', confidence: 0.89, x: 10, y: 60, w: 50, h: 30 },
      ],
    },
    status: 'assigned',
    assignedEmployeeId: 'employee-1',
    assignedEmployeeName: 'Amit Patel',
  },
  {
    id: 'comp-102',
    citizenId: 'citizen-1',
    citizenName: 'Rahul Sharma',
    image: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80', // Broken glass/trash
    textComplaint: 'Broken beer bottles and glass pieces on the sidewalk near Sector 4 Metro Station. Dangerous for children.',
    location: {
      lat: 28.6280,
      lng: 77.2200,
      address: 'Metro Station Path, Sector 4',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110003',
    },
    timestamp: new Date(Date.now() - 10 * 3600000).toISOString(), // 10 hours ago
    aiResult: {
      wasteType: 'glass',
      confidence: 0.88,
      area: '1.2 sq meters',
      quantity: 'Approx. 15-20 sharp shards',
      density: 'medium',
      boxes: [
        { label: 'Glass Bottle', confidence: 0.91, x: 15, y: 45, w: 20, h: 25 },
        { label: 'Glass Shard', confidence: 0.85, x: 45, y: 60, w: 12, h: 12 },
      ],
    },
    status: 'pending',
  },
  {
    id: 'comp-103',
    citizenId: 'citizen-1',
    citizenName: 'Rahul Sharma',
    image: 'https://images.unsplash.com/photo-1503596476-1c12a8ba09a9?auto=format&fit=crop&w=800&q=80', // Dry leaves/organic heap
    textComplaint: 'Organic waste, garden trimmings, and rotting food dumped on the corner of Market Road.',
    location: {
      lat: 28.5980,
      lng: 77.1950,
      address: 'Opposite Sweet Mart, Market Road, Saket',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110017',
    },
    timestamp: new Date(Date.now() - 24 * 3600000).toISOString(), // 24 hours ago
    aiResult: {
      wasteType: 'organic',
      confidence: 0.91,
      area: '4.0 sq meters',
      quantity: 'Approx. 80kg decomposing waste',
      density: 'high',
      boxes: [
        { label: 'Organic Compost', confidence: 0.93, x: 30, y: 20, w: 45, h: 55 },
      ],
    },
    status: 'verified',
    assignedEmployeeId: 'employee-1',
    assignedEmployeeName: 'Amit Patel',
    beforeImage: 'https://images.unsplash.com/photo-1503596476-1c12a8ba09a9?auto=format&fit=crop&w=800&q=80',
    afterImage: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80', // Clean street
    verifiedAt: new Date(Date.now() - 2 * 3600000).toISOString(),
    rewardPoints: 50,
  },
];

// Mock Leaderboard Collection
let leaderboard: LeaderboardEntry[] = [
  { userId: 'employee-1', name: 'Amit Patel (Staff)', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80', role: 'employee', points: 2200, rank: 1 },
  { userId: 'citizen-2', name: 'Priya Patel', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80', role: 'citizen', points: 850, rank: 2 },
  { userId: 'citizen-3', name: 'Vikram Singh', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80', role: 'citizen', points: 620, rank: 3 },
  { userId: 'citizen-1', name: 'Rahul Sharma (You)', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80', role: 'citizen', points: 450, rank: 4 },
  { userId: 'citizen-4', name: 'Neha Gupta', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80', role: 'citizen', points: 310, rank: 5 },
];

// Mock Reward History
let wallet: WalletData = {
  balance: 450,
  transactions: [
    { id: 'tx-01', title: 'Plastic cleanup Connaught Place verified', points: 50, type: 'earn', date: new Date(Date.now() - 3600000).toISOString() },
    { id: 'tx-02', title: 'Composting awareness quiz completed', points: 100, type: 'earn', date: new Date(Date.now() - 86400000).toISOString() },
    { id: 'tx-03', title: 'Recycled Paper campaign upload', points: 50, type: 'earn', date: new Date(Date.now() - 2 * 86400000).toISOString() },
    { id: 'tx-04', title: 'Redeemed Eco-Bag Discount Coupon', points: -200, type: 'redeem', date: new Date(Date.now() - 4 * 86400000).toISOString() },
    { id: 'tx-05', title: 'Glass litter Saket report verified', points: 50, type: 'earn', date: new Date(Date.now() - 5 * 86400000).toISOString() },
  ],
};

// Mock Quizzes for Awareness
const quizzes: QuizQuestion[] = [
  {
    id: 'quiz-1',
    question: 'What is the correct way to dispose of electronic waste (e-waste) like cellphones or chargers?',
    options: [
      'Dump them in the general mixed household trash bin',
      'Wash them in water and compost them in backyard soil',
      'Hand them over to certified e-waste recyclers or municipal drop-off centers',
      'Burn them to melt metals down',
    ],
    correctAnswerIndex: 2,
    explanation: 'E-waste contains heavy metals (lead, mercury, cadmium) that can leach into soil and water. They must be processed safely by specialized e-waste handlers.',
  },
  {
    id: 'quiz-2',
    question: 'Which of these items CANNOT be composted under organic composting guidelines?',
    options: [
      'Vegetable peels and rotten fruits',
      'Plastic containers and aluminum foil wrappers',
      'Dry autumn leaves and grass clippings',
      'Coffee grounds and tea leaves',
    ],
    correctAnswerIndex: 1,
    explanation: 'Non-biodegradable synthetic materials like plastics and metals do not break down in compost and release toxic microplastics or chemicals.',
  },
  {
    id: 'quiz-3',
    question: 'How much time does a typical plastic bottle take to decompose in a landfill?',
    options: [
      'About 5 to 10 years',
      'Around 50 years',
      'More than 450 years',
      'It decomposes in 6 months',
    ],
    correctAnswerIndex: 2,
    explanation: 'Most plastic water bottles are made of PET, which is highly resistant to natural decomposition. It is estimated to take up to 450-500 years to fully break down.',
  },
];

// Mock Map Hotspots
const hotspots: Hotspot[] = [
  { id: 'hot-1', lat: 28.6139, lng: 77.2090, intensity: 8, city: 'New Delhi', complaintsCount: 12 },
  { id: 'hot-2', lat: 28.6280, lng: 77.2200, intensity: 5, city: 'New Delhi', complaintsCount: 7 },
  { id: 'hot-3', lat: 28.5800, lng: 77.1600, intensity: 9, city: 'New Delhi', complaintsCount: 16 },
  { id: 'hot-4', lat: 28.5500, lng: 77.2500, intensity: 3, city: 'New Delhi', complaintsCount: 3 },
  { id: 'hot-5', lat: 28.6500, lng: 77.1200, intensity: 7, city: 'New Delhi', complaintsCount: 10 },
];

// Mock AI Hotspot Predictions
const predictions: PredictionData[] = [
  { areaName: 'Connaught Place Central Block', currentPollutionIndex: 68, predictedPollutionNextWeek: 82, mostCommonWasteType: 'plastic', recommendedFrequency: 'Twice Daily' },
  { areaName: 'Saket Market Square', currentPollutionIndex: 54, predictedPollutionNextWeek: 48, mostCommonWasteType: 'organic', recommendedFrequency: 'Daily' },
  { areaName: 'Dwarka Sector 10 Outer Sidewalks', currentPollutionIndex: 75, predictedPollutionNextWeek: 89, mostCommonWasteType: 'e_waste', recommendedFrequency: 'Every 2 days' },
  { areaName: 'Okhla Industrial Area Path', currentPollutionIndex: 82, predictedPollutionNextWeek: 94, mostCommonWasteType: 'metal', recommendedFrequency: 'Twice Daily' },
  { areaName: 'Rohini Institutional Block', currentPollutionIndex: 35, predictedPollutionNextWeek: 41, mostCommonWasteType: 'paper', recommendedFrequency: 'Three times weekly' },
];

// Push notifications log
let notifications: Array<{ id: string, title: string, body: string, date: string, read: boolean }> = [
  { id: 'notif-1', title: 'Complaint Registered', body: 'Your plastic garbage report at Connaught Place has been successfully filed with ID comp-101.', date: new Date(Date.now() - 3600000 * 3).toISOString(), read: true },
  { id: 'notif-2', title: 'Team Assigned', body: 'Municipality Team "Green Sweepers" (Amit Patel) has been assigned to clear garbage at Central Park entrance.', date: new Date(Date.now() - 3600000 * 2.5).toISOString(), read: false },
  { id: 'notif-3', title: 'Eco Points Earned!', body: 'Congratulations! Your Saket Market report was approved by the Municipal admin. +50 Reward points added to your wallet!', date: new Date(Date.now() - 3600000 * 2).toISOString(), read: false },
];

// Helper functions for mock AI fallbacks
function generateMockAIDetection(wasteTypeHint?: string): AIResult {
  const wasteTypes: WasteType[] = ['plastic', 'paper', 'glass', 'metal', 'organic', 'e_waste', 'mixed'];
  const type = (wasteTypeHint && wasteTypes.includes(wasteTypeHint as WasteType)) ? (wasteTypeHint as WasteType) : wasteTypes[Math.floor(Math.random() * wasteTypes.length)];
  
  const labelsMap: Record<WasteType, string[]> = {
    plastic: ['Plastic Bottle', 'Wrapping Sheet', 'Polythene Bag', 'Plastic Container'],
    paper: ['Cardboard Box', 'Newspaper Shreds', 'Paper Cup', 'Torn Flyer'],
    glass: ['Broken Glass', 'Soda Bottle', 'Beer Bottle Shards'],
    metal: ['Soda Can', 'Metal Pipe scrap', 'Tin Foil Heap'],
    organic: ['Decomposing Leaves', 'Fruit Waste', 'Rotting Food Pile'],
    e_waste: ['Broken Charger', 'Li-ion Battery Cell', 'Damaged Computer Mouse'],
    mixed: ['Mixed Household Litter', 'Unsorted Trash Bag', 'Street Sweeping Pile'],
  };

  const detectedLabels = labelsMap[type];
  const confidence = parseFloat((0.80 + Math.random() * 0.18).toFixed(2));
  const qty = `${Math.floor(5 + Math.random() * 15)} items/approx. ${Math.floor(2 + Math.random() * 10)}kg`;
  
  const boxes = detectedLabels.map((lbl, idx) => ({
    label: lbl,
    confidence: parseFloat((0.75 + Math.random() * 0.23).toFixed(2)),
    x: 10 + idx * 25 + Math.floor(Math.random() * 10),
    y: 20 + Math.floor(Math.random() * 30),
    w: 15 + Math.floor(Math.random() * 15),
    h: 15 + Math.floor(Math.random() * 20),
  }));

  return {
    wasteType: type,
    confidence,
    area: `${(1.0 + Math.random() * 3.5).toFixed(1)} sq meters`,
    quantity: qty,
    density: confidence > 0.90 ? 'high' : confidence > 0.83 ? 'medium' : 'low',
    boxes,
  };
}

// ==========================================
// REST API ENDPOINTS
// ==========================================

// Authenticate user (Login, Google, Phone OTP)
app.post('/api/auth/login', (req, res) => {
  const { email, role, phone, method } = req.body;
  
  // Find standard user or simulate
  let foundUser = users.find(u => u.role === role);
  
  if (method === 'phone') {
    foundUser = users.find(u => u.phone.replace(/\s+/g, '') === phone.replace(/\s+/g, '')) || foundUser;
  } else if (email) {
    foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase()) || foundUser;
  }

  if (!foundUser) {
    return res.status(404).json({ error: 'User not found for this role/email' });
  }

  res.json({
    token: `mock-jwt-token-for-${foundUser.id}`,
    user: foundUser,
  });
});

app.post('/api/auth/register', (req, res) => {
  const { name, email, phone, role } = req.body;
  
  const newUser: UserProfile = {
    id: `citizen-${users.length + 1}`,
    name: name || 'New Citizen',
    email: email || 'citizen@email.com',
    phone: phone || '+91 00000 00000',
    role: role || 'citizen',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    rewardPoints: 100, // starting points
    complaintsCount: 0,
    level: 1,
    achievements: ['Eco Rookie'],
  };

  users.push(newUser);
  res.json({ token: `mock-jwt-token-for-${newUser.id}`, user: newUser });
});

// Get profiles
app.get('/api/users', (req, res) => {
  res.json(users);
});

// ==========================================
// COMPLAINTS WORKFLOW API
// ==========================================

// Get all complaints
app.get('/api/complaints', (req, res) => {
  res.json(complaints);
});

// Create new complaint
app.post('/api/complaints', (req, res) => {
  const { citizenId, citizenName, image, textComplaint, voiceComplaint, location, aiResult } = req.body;

  const newComplaint: Complaint = {
    id: `comp-${100 + complaints.length + 1}`,
    citizenId: citizenId || 'citizen-1',
    citizenName: citizenName || 'Rahul Sharma',
    image: image || 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=800&q=80',
    textComplaint: textComplaint || '',
    voiceComplaint: voiceComplaint,
    location: location || {
      lat: 28.6139 + (Math.random() - 0.5) * 0.1,
      lng: 77.2090 + (Math.random() - 0.5) * 0.1,
      address: 'Near Central Lane Road',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110001',
    },
    timestamp: new Date().toISOString(),
    aiResult: aiResult || generateMockAIDetection(),
    status: 'pending',
  };

  complaints.push(newComplaint);

  // Update user statistics
  const user = users.find(u => u.id === newComplaint.citizenId);
  if (user) {
    user.complaintsCount += 1;
  }

  // Push an automated notification
  notifications.unshift({
    id: `notif-${Date.now()}`,
    title: 'New Complaint Filed',
    body: `Your smart complaint for ${newComplaint.aiResult?.wasteType || 'general'} waste has been logged successfully (ID: ${newComplaint.id}).`,
    date: new Date().toISOString(),
    read: false,
  });

  res.status(201).json(newComplaint);
});

// Update complaint status or add employee logs
app.patch('/api/complaints/:id', (req, res) => {
  const { id } = req.params;
  const { status, assignedEmployeeId, assignedEmployeeName, beforeImage, afterImage } = req.body;

  const complaint = complaints.find(c => c.id === id);

  if (!complaint) {
    return res.status(404).json({ error: 'Complaint not found' });
  }

  if (status) complaint.status = status;
  if (assignedEmployeeId) {
    complaint.assignedEmployeeId = assignedEmployeeId;
    complaint.assignedEmployeeName = assignedEmployeeName || 'Amit Patel';
    
    // Auto trigger push notification
    notifications.unshift({
      id: `notif-${Date.now()}`,
      title: 'Cleaning Team Assigned',
      body: `Cleaning Specialist ${complaint.assignedEmployeeName} has been dispatched to clear waste at ${complaint.location.address}.`,
      date: new Date().toISOString(),
      read: false,
    });
  }
  if (beforeImage) complaint.beforeImage = beforeImage;
  if (afterImage) complaint.afterImage = afterImage;

  // Verification stage completes: User / Admin approves
  if (status === 'verified') {
    complaint.verifiedAt = new Date().toISOString();
    const points = 50;
    complaint.rewardPoints = points;

    // Credit Citizen
    const citizen = users.find(u => u.id === complaint.citizenId);
    if (citizen) {
      citizen.rewardPoints += points;
      // Add transaction to wallet
      wallet.balance += points;
      wallet.transactions.unshift({
        id: `tx-${Date.now()}`,
        title: `Verified Report at ${complaint.location.address}`,
        points: points,
        type: 'earn',
        date: new Date().toISOString(),
      });
      
      // Update citizen rankings
      const citizenRankIdx = leaderboard.findIndex(l => l.userId === citizen.id);
      if (citizenRankIdx !== -1) {
        leaderboard[citizenRankIdx].points = citizen.rewardPoints;
      } else {
        leaderboard.push({
          userId: citizen.id,
          name: `${citizen.name} (You)`,
          avatar: citizen.avatar,
          role: 'citizen',
          points: citizen.rewardPoints,
          rank: leaderboard.length + 1,
        });
      }
      leaderboard.sort((a, b) => b.points - a.points);
      leaderboard.forEach((l, idx) => l.rank = idx + 1);
    }

    // Credit Cleaning Employee (Performance rewards)
    if (complaint.assignedEmployeeId) {
      const employee = users.find(u => u.id === complaint.assignedEmployeeId);
      if (employee) {
        employee.rewardPoints += 100; // performance score +100
        employee.complaintsCount += 1; // task completed +1
        
        const empLeaderIdx = leaderboard.findIndex(l => l.userId === employee.id);
        if (empLeaderIdx !== -1) {
          leaderboard[empLeaderIdx].points = employee.rewardPoints;
        }
        leaderboard.sort((a, b) => b.points - a.points);
        leaderboard.forEach((l, idx) => l.rank = idx + 1);
      }
    }

    // Notify citizen
    notifications.unshift({
      id: `notif-${Date.now()}`,
      title: 'Eco Points Rewarded! 🎉',
      body: `Congratulations! Your garbage cleanup has been verified. You earned +50 points! Wallet Balance: ${wallet.balance} pts.`,
      date: new Date().toISOString(),
      read: false,
    });
  }

  res.json(complaint);
});

// Delete complaint
app.delete('/api/complaints/:id', (req, res) => {
  const { id } = req.params;
  const idx = complaints.findIndex(c => c.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Complaint not found' });
  }
  complaints.splice(idx, 1);
  res.json({ message: 'Complaint deleted successfully' });
});

// ==========================================
// AI GARBAGE DETECTION API (Gemini Integration)
// ==========================================

app.post('/api/ai/detect', async (req, res) => {
  const { base64Image, wasteTypeHint } = req.body;

  if (!base64Image) {
    return res.status(400).json({ error: 'Missing base64Image data' });
  }

  // If Gemini SDK is NOT available, return high-fidelity fallback mock detection immediately
  if (!ai) {
    console.log('Gemini API key is not active. Generating fallback mock AI results.');
    const mockResult = generateMockAIDetection(wasteTypeHint);
    return res.json(mockResult);
  }

  try {
    const rawBase64 = base64Image.replace(/^data:image\/\w+;base64,/, '');
    
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: rawBase64,
          },
        },
        `Analyze this image of discarded trash or public litter.
        Classify it into one of the main categories of waste: "plastic", "paper", "glass", "metal", "organic", "e_waste", or "mixed".
        You MUST provide bounding box estimations for items found. The coordinates (x, y, w, h) must represent percentages of width and height from the top-left (0 to 100).
        Return ONLY a JSON response in this exact schema format:
        {
          "wasteType": "plastic" | "paper" | "glass" | "metal" | "organic" | "e_waste" | "mixed",
          "confidence": number (between 0.0 and 1.0),
          "area": string (estimated physical area of garbage, e.g. "1.5 sq meters"),
          "quantity": string (estimated amount/items, e.g. "Approx. 12 bottles"),
          "density": "low" | "medium" | "high",
          "boxes": [
            { "label": string, "confidence": number, "x": number, "y": number, "w": number, "h": number }
          ]
        }
        Do not wrap the response in markdown blocks like \`\`\`json. Return pure JSON text only.`
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '';
    console.log('Gemini raw detection response:', text);
    const parsed: AIResult = JSON.parse(text.trim());
    res.json(parsed);

  } catch (err: any) {
    console.error('Error in Gemini detection endpoint:', err);
    // Graceful fallback on rate limit / model errors
    const mockResult = generateMockAIDetection(wasteTypeHint);
    res.json(mockResult);
  }
});

// ==========================================
// VOICE COMPLAINT TRANSLATION/TRANSCRIPTION API
// ==========================================

app.post('/api/ai/voice-complaint', async (req, res) => {
  const { voiceTextPrompt } = req.body;

  if (!voiceTextPrompt) {
    return res.status(400).json({ error: 'Missing voiceTextPrompt parameter' });
  }

  if (!ai) {
    // Mock Hindi-to-English transcription and classification
    const isHindi = /kachra|safai|gandagi|yahan|hai|gate/i.test(voiceTextPrompt);
    res.json({
      transcription: isHindi 
        ? "Huge accumulation of plastic water bottles and wrappers on the sidewalk near the market entry."
        : voiceTextPrompt,
      hindiTranslation: isHindi ? voiceTextPrompt : "यहाँ रास्ते के किनारे प्लास्टिक की बोतलों और रैपरों का भारी जमाव हो गया है।",
      detectedWasteType: 'plastic',
    });
    return;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `The user spoke or typed this garbage complaint: "${voiceTextPrompt}".
      It could be in Hindi, Hinglish (Hindi written in English alphabets like "yahan bohot kachra hai"), or English.
      Perform these steps:
      1. Translate the statement into grammatically clear, concise English.
      2. Transcribe/translate the statement back into Hindi script (Devanagari) to verify accuracy.
      3. Classify the main garbage waste type described: "plastic", "paper", "glass", "metal", "organic", "e_waste", or "mixed".
      Return ONLY a JSON response in this exact format:
      {
        "transcription": "Your English translation here",
        "hindiTranslation": "Your Hindi translation in Devanagari script here",
        "detectedWasteType": "plastic" | "paper" | "glass" | "metal" | "organic" | "e_waste" | "mixed"
      }
      Do not include any markdown fences or explanation. Return pure JSON text.`,
      config: {
        responseMimeType: 'application/json',
      }
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    res.json(parsed);
  } catch (err) {
    console.error('Error transcribing voice via Gemini:', err);
    res.json({
      transcription: voiceTextPrompt,
      hindiTranslation: "यहाँ कचरा डंप किया हुआ है, कृपया इसे जल्द से जल्द साफ करें।",
      detectedWasteType: 'mixed',
    });
  }
});

// ==========================================
// AI RECYCLING CHATBOT API
// ==========================================

app.post('/api/ai/chatbot', async (req, res) => {
  const { messages } = req.body; // Array of ChatMessage objects

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Missing or invalid messages parameter' });
  }

  const userMessage = messages[messages.length - 1]?.text || 'Hello';

  if (!ai) {
    // Mock recycling assistant chatbot replies
    let reply = "Hello! I am BinBuddy AI, your environmental companion. I can help you with waste segregation, composting, e-waste guidelines, carbon footprint calculations, or logging a complaint! How can I assist you today?";
    const msgLower = userMessage.toLowerCase();
    
    if (msgLower.includes('plastic') || msgLower.includes('recycle')) {
      reply = "Plastic bottles can be recycled! Make sure you wash out any residue, compress the bottles to save space, and discard them in the BLUE bin. Let me know if you would like to test your recycling knowledge in our Quiz!";
    } else if (msgLower.includes('compost') || msgLower.includes('organic') || msgLower.includes('fruit')) {
      reply = "Decomposing leaves, vegetable peels, and tea dregs are perfect organic waste for home composting! Do not add plastic or metal foil. Put them in the GREEN bin to help create nutrient-rich compost soil.";
    } else if (msgLower.includes('complain') || msgLower.includes('report') || msgLower.includes('litter')) {
      reply = "To report garbage, go to our scan panel or map dashboard. Tap 'Scan Garbage' or trigger GPS auto-reporting. I can also help you draft a voice complaint instantly!";
    } else if (msgLower.includes('wallet') || msgLower.includes('points') || msgLower.includes('rewards')) {
      reply = "You receive 50 Eco Points for every verified garbage report you file! Employees receive 100 points for completing assigned tasks. You can redeem these points in the 'Redeem Points' wallet tab!";
    }
    
    res.json({ text: reply });
    return;
  }

  try {
    // Formulate a conversation context for Gemini
    const geminiHistory = messages.map(m => ({
      role: m.sender === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    }));

    // Generate response using gemini-3.5-flash
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        {
          role: 'user',
          parts: [{
            text: `You are BinBuddy, the smart AI garbage assistant. You assist citizens with waste segregation, recycling guides, home organic composting, explaining government cleanliness campaigns (like Swachh Bharat), environment tips, and instructions on how to use the BinBuddy app. Keep your tone encouraging, professional, and slightly conversational. Answer clearly and concisely.
            
            Current user query: "${userMessage}"`
          }]
        }
      ],
      config: {
        systemInstruction: "You are BinBuddy, a friendly environmental AI recycling assistant. You guide users on proper waste disposal, segregation blue/green bins, composting, points rewards, and clean environment guidelines.",
      },
    });

    res.json({ text: response.text || 'I am sorry, I had trouble parsing that. Please try again.' });
  } catch (err) {
    console.error('Error in Gemini Chatbot endpoint:', err);
    res.json({ text: 'Excuse me, I am experiencing a small connection glitch, but remember to put plastics in the Blue bin and organic waste in the Green bin!' });
  }
});

// ==========================================
// STATIC UTILITIES & ANALYTICS
// ==========================================

// Get analytics
app.get('/api/analytics', (req, res) => {
  res.json({
    hotspots,
    predictions,
    weeklyPollution: [
      { day: 'Mon', pollution: 42, cleaned: 38 },
      { day: 'Tue', pollution: 55, cleaned: 48 },
      { day: 'Wed', pollution: 72, cleaned: 68 },
      { day: 'Thu', pollution: 48, cleaned: 52 },
      { day: 'Fri', pollution: 85, cleaned: 78 },
      { day: 'Sat', pollution: 92, cleaned: 80 },
      { day: 'Sun', pollution: 35, cleaned: 42 },
    ],
    wasteDistribution: [
      { name: 'Plastic', value: 42, color: '#3b82f6' },
      { name: 'Paper', value: 18, color: '#10b981' },
      { name: 'Glass', value: 12, color: '#f59e0b' },
      { name: 'Metal', value: 8, color: '#ef4444' },
      { name: 'Organic', value: 15, color: '#8b5cf6' },
      { name: 'E-Waste', value: 5, color: '#6b7280' },
    ],
    generalStats: {
      totalComplaints: complaints.length + 22,
      todayComplaints: complaints.filter(c => new Date(c.timestamp).toDateString() === new Date().toDateString()).length + 4,
      pendingComplaints: complaints.filter(c => c.status === 'pending').length,
      completedComplaints: complaints.filter(c => c.status === 'verified').length + 15,
      activeEmployees: 3,
      availableTeams: 2,
    }
  });
});

// Get quizzes
app.get('/api/quizzes', (req, res) => {
  res.json(quizzes);
});

// Get reward history & wallet
app.get('/api/rewards/wallet', (req, res) => {
  res.json(wallet);
});

// Redeem reward points
app.post('/api/rewards/redeem', (req, res) => {
  const { title, points } = req.body;
  if (!points || wallet.balance < points) {
    return res.status(400).json({ error: 'Insufficient balance' });
  }

  wallet.balance -= points;
  wallet.transactions.unshift({
    id: `tx-${Date.now()}`,
    title: `Redeemed: ${title}`,
    points: -points,
    type: 'redeem',
    date: new Date().toISOString(),
  });

  // Credit Citizen points
  const citizen = users.find(u => u.role === 'citizen');
  if (citizen) {
    citizen.rewardPoints = wallet.balance;
    const leaderIdx = leaderboard.findIndex(l => l.userId === citizen.id);
    if (leaderIdx !== -1) {
      leaderboard[leaderIdx].points = wallet.balance;
    }
    leaderboard.sort((a, b) => b.points - a.points);
    leaderboard.forEach((l, idx) => l.rank = idx + 1);
  }

  res.json({ success: true, balance: wallet.balance, transactions: wallet.transactions });
});

// Get leaderboard
app.get('/api/leaderboard', (req, res) => {
  res.json(leaderboard);
});

// Get notifications
app.get('/api/notifications', (req, res) => {
  res.json(notifications);
});

// Mark notifications as read
app.post('/api/notifications/read', (req, res) => {
  notifications.forEach(n => n.read = true);
  res.json({ success: true, notifications });
});

// ==========================================
// VITE OR STATIC BUILD MIDDLEWARE
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BinBuddy Server booted on port ${PORT}`);
    console.log(`Access the application at http://0.0.0.0:${PORT}`);
  });
}

startServer();
