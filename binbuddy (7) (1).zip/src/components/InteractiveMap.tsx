/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MapPin, Navigation, Eye, CheckCircle2, ShieldAlert, Layers, ZoomIn, ZoomOut, Compass, Trash2 } from 'lucide-react';
import { Complaint, UserRole } from '../types';

interface InteractiveMapProps {
  complaints: Complaint[];
  activeRole: UserRole;
  onSelectComplaint?: (complaint: Complaint) => void;
  onUpdateComplaintStatus?: (id: string, status: any) => void;
  selectedComplaintId?: string | null;
}

// Fixed bounds of Connaught Place map mockup in SVG coordinates
// Center is New Delhi CP area
const CP_NODES = [
  { id: 'bin-1', name: 'Smart Dustbin - Connaught Circle A', lat: 28.6145, lng: 77.2085, type: 'bin', fill: 45 },
  { id: 'bin-2', name: 'Smart Dustbin - Janpath Road Cross', lat: 28.6210, lng: 77.2180, type: 'bin', fill: 88 },
  { id: 'bin-3', name: 'Smart Dustbin - Saket Market Entrance', lat: 28.5990, lng: 77.1940, type: 'bin', fill: 20 },
];

export default function InteractiveMap({
  complaints,
  activeRole,
  onSelectComplaint,
  onUpdateComplaintStatus,
  selectedComplaintId,
}: InteractiveMapProps) {
  const [zoom, setZoom] = useState<number>(1.2);
  const [viewMode, setViewMode] = useState<'standard' | 'heatmap' | 'cluster'>('standard');
  const [showDustbins, setShowDustbins] = useState<boolean>(true);
  const [showRoutes, setShowRoutes] = useState<boolean>(true);

  // Focus complaint state
  const selectedComplaint = complaints.find(c => c.id === selectedComplaintId);

  // Map coordinates latitude/longitude to SVG coordinate viewport (800x400)
  // Let's create a bounding box mapping New Delhi coordinates around Connaught Place
  // Lat: 28.55 to 28.65, Lng: 77.10 to 77.30
  const convertLatLngToXY = (lat: number, lng: number) => {
    const latMin = 28.52;
    const latMax = 28.66;
    const lngMin = 77.10;
    const lngMax = 77.28;

    const x = ((lng - lngMin) / (lngMax - lngMin)) * 800;
    // Y is inverted because SVG 0 is top
    const y = 400 - ((lat - latMin) / (latMax - latMin)) * 400;

    return { x, y };
  };

  const getMarkerColorClass = (status: string) => {
    switch (status) {
      case 'verified':
      case 'completed':
        return 'fill-emerald-500 stroke-emerald-950';
      case 'in_progress':
      case 'accepted':
        return 'fill-amber-500 stroke-amber-950 animate-pulse';
      case 'pending':
        return 'fill-red-500 stroke-red-950 animate-bounce';
      default:
        return 'fill-zinc-500 stroke-zinc-950';
    }
  };

  const getMarkerRingColor = (status: string) => {
    switch (status) {
      case 'verified':
      case 'completed':
        return 'border-emerald-500/40 bg-emerald-500/10';
      case 'in_progress':
      case 'accepted':
        return 'border-amber-500/40 bg-amber-500/10';
      case 'pending':
        return 'border-red-500/40 bg-red-500/10';
      default:
        return 'border-zinc-500/40 bg-zinc-500/10';
    }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col h-[520px] shadow-2xl relative" id="binbuddy-interactive-map">
      {/* Map Header bar with tools */}
      <div className="p-4 bg-zinc-950/90 border-b border-zinc-800/80 flex flex-wrap items-center justify-between gap-3 z-10">
        <div className="flex items-center gap-2">
          <Compass className="w-5 h-5 text-emerald-400 animate-spin-slow" />
          <h3 className="text-sm font-semibold text-zinc-100">GPS Auto-Location Live Console</h3>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-0.5 flex">
            <button
              onClick={() => setViewMode('standard')}
              className={`px-3 py-1 rounded text-xs font-medium transition-all ${viewMode === 'standard' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Standard Map
            </button>
            <button
              onClick={() => setViewMode('heatmap')}
              className={`px-3 py-1 rounded text-xs font-medium transition-all ${viewMode === 'heatmap' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Heatmap Mode
            </button>
          </div>

          <button
            onClick={() => setShowDustbins(!showDustbins)}
            className={`px-2.5 py-1 rounded border text-xs flex items-center gap-1.5 transition-all ${showDustbins ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-400' : 'border-zinc-800 bg-zinc-900 text-zinc-500'}`}
            title="Toggle Smart Dustbins"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Dustbins</span>
          </button>
        </div>
      </div>

      {/* Main Map Viewer Canvas */}
      <div className="flex-1 bg-zinc-950 relative overflow-hidden select-none">
        {/* Vector Background Road grid map representation */}
        <svg
          className="absolute inset-0 w-full h-full text-zinc-800/20 transition-transform duration-300 origin-center"
          style={{ transform: `scale(${zoom})` }}
          viewBox="0 0 800 400"
        >
          {/* Circular outer radial lines representing Delhi rings */}
          <circle cx="400" cy="200" r="120" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="5,5" />
          <circle cx="400" cy="200" r="260" fill="none" stroke="currentColor" strokeWidth="1" />
          
          {/* Intersecting central road layouts of CP */}
          <line x1="100" y1="50" x2="700" y2="350" stroke="currentColor" strokeWidth="1.5" />
          <line x1="100" y1="350" x2="700" y2="50" stroke="currentColor" strokeWidth="1.5" />
          <line x1="400" y1="0" x2="400" y2="400" stroke="currentColor" strokeWidth="2" />
          <line x1="0" y1="200" x2="800" y2="200" stroke="currentColor" strokeWidth="2" />

          {/* Connective arterial lanes */}
          <path d="M 280,100 Q 400,50 520,100" fill="none" stroke="currentColor" strokeWidth="1" />
          <path d="M 280,300 Q 400,350 520,300" fill="none" stroke="currentColor" strokeWidth="1" />
          <path d="M 150,150 Q 250,200 150,250" fill="none" stroke="currentColor" strokeWidth="1" />
          <path d="M 650,150 Q 550,200 650,250" fill="none" stroke="currentColor" strokeWidth="1" />

          {/* Forest/Parks areas (represented in green styled polygons) */}
          <polygon points="350,180 450,180 430,220 370,220" className="fill-emerald-950/25 stroke-emerald-900/20" strokeWidth="1" />
          <circle cx="200" cy="100" r="45" className="fill-emerald-950/15 stroke-emerald-900/10" />
          <circle cx="620" cy="300" r="50" className="fill-emerald-950/15 stroke-emerald-900/10" />

          {/* Render Heatmap gradients under markers if Heatmap mode is active */}
          {viewMode === 'heatmap' && complaints.map((comp) => {
            const { x, y } = convertLatLngToXY(comp.location.lat, comp.location.lng);
            const intensityColor = comp.status === 'pending' ? 'rgba(239, 68, 68, 0.45)' : comp.status === 'in_progress' ? 'rgba(245, 158, 11, 0.35)' : 'rgba(16, 185, 129, 0.15)';
            const radius = comp.status === 'pending' ? 45 : 30;
            return (
              <g key={`heat-${comp.id}`}>
                <defs>
                  <radialGradient id={`grad-${comp.id}`}>
                    <stop offset="0%" stopColor={intensityColor === 'rgba(239, 68, 68, 0.45)' ? '#ef4444' : '#f59e0b'} stopOpacity="0.6" />
                    <stop offset="100%" stopColor="#18181b" stopOpacity="0" />
                  </radialGradient>
                </defs>
                <circle cx={x} cy={y} r={radius * 1.5} fill={`url(#grad-${comp.id})`} />
              </g>
            );
          })}

          {/* Employee Route Optimizer line - simulated path in action */}
          {showRoutes && activeRole === 'employee' && selectedComplaint && selectedComplaint.status === 'in_progress' && (
            <g>
              {/* Employee current mock GPS at 28.5800, 77.1600 */}
              {(() => {
                const empPos = convertLatLngToXY(28.5800, 77.1600);
                const targetPos = convertLatLngToXY(selectedComplaint.location.lat, selectedComplaint.location.lng);
                return (
                  <>
                    <path
                      d={`M ${empPos.x},${empPos.y} Q ${(empPos.x + targetPos.x) / 2 + 30},${(empPos.y + targetPos.y) / 2 - 30} ${targetPos.x},${targetPos.y}`}
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="3"
                      strokeDasharray="6,4"
                      className="animate-dash"
                    />
                    <circle cx={empPos.x} cy={empPos.y} r="6" fill="#3b82f6" className="animate-pulse" />
                    <circle cx={empPos.x} cy={empPos.y} r="1.5" fill="#ffffff" />
                  </>
                );
              })()}
            </g>
          )}

          {/* Render Smart Dustbin Locations */}
          {showDustbins && CP_NODES.map((node) => {
            const { x, y } = convertLatLngToXY(node.lat, node.lng);
            return (
              <g key={node.id} className="cursor-pointer group">
                <circle
                  cx={x}
                  cy={y}
                  r="6"
                  className={`${node.fill > 80 ? 'fill-red-400 stroke-red-950' : 'fill-blue-400 stroke-blue-950'} transition-all`}
                  strokeWidth="1.5"
                />
                <circle
                  cx={x}
                  cy={y}
                  r="12"
                  className="stroke-blue-400/20 fill-none group-hover:scale-125 transition-transform"
                />
              </g>
            );
          })}

          {/* Render Complaint Pin Markers */}
          {viewMode !== 'heatmap' && complaints.map((comp) => {
            const { x, y } = convertLatLngToXY(comp.location.lat, comp.location.lng);
            const isSelected = selectedComplaintId === comp.id;
            return (
              <g
                key={comp.id}
                onClick={() => onSelectComplaint?.(comp)}
                className="cursor-pointer group"
              >
                {/* Ping rings */}
                <circle
                  cx={x}
                  cy={y}
                  r={isSelected ? 18 : 12}
                  className={`fill-none stroke-2 transition-all ${
                    comp.status === 'pending'
                      ? 'stroke-red-500/20 animate-pulse'
                      : comp.status === 'in_progress'
                      ? 'stroke-amber-500/20 animate-pulse'
                      : 'stroke-emerald-500/20'
                  }`}
                />
                {/* Base Pin pinhead */}
                <circle
                  cx={x}
                  cy={y}
                  r={isSelected ? 8 : 5}
                  className={`${getMarkerColorClass(comp.status)} stroke-1 transition-all group-hover:scale-125`}
                />
                <circle cx={x} cy={y} r="2" fill="#fff" />
              </g>
            );
          })}
        </svg>

        {/* Zoom controls float */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-1.5 z-10">
          <button
            onClick={() => setZoom(Math.min(zoom + 0.2, 3))}
            className="w-8 h-8 rounded-lg bg-zinc-900/95 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-all shadow-md"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoom(Math.max(zoom - 0.2, 0.8))}
            className="w-8 h-8 rounded-lg bg-zinc-900/95 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-all shadow-md"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
        </div>

        {/* Map Legend card */}
        <div className="absolute top-4 left-4 bg-zinc-900/95 border border-zinc-800 rounded-xl p-3 shadow-lg max-w-[200px] text-xs backdrop-blur-md z-10">
          <p className="font-semibold text-zinc-300 mb-1.5 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-emerald-400" /> Map Legend
          </p>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
              <span className="text-zinc-400">Highly Polluted (Pending)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span className="text-zinc-400">Moderately Dirty (In Progress)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-zinc-400">Cleaned Area (Verified)</span>
            </div>
            {showDustbins && (
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-400" />
                <span className="text-zinc-400">Smart Dustbin</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Selected Item Drawer Panel at Bottom */}
      {selectedComplaint && (
        <div className="bg-zinc-900 border-t border-zinc-800 p-4 grid grid-cols-1 md:grid-cols-3 gap-4 backdrop-blur-md z-10 transition-all duration-300">
          <div className="flex gap-3">
            <img
              src={selectedComplaint.image}
              alt="Report proof"
              className="w-16 h-16 md:w-20 md:h-20 rounded-lg object-cover border border-zinc-800/80"
            />
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-zinc-950 px-1.5 py-0.5 rounded text-zinc-400">
                  {selectedComplaint.id}
                </span>
                <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                  selectedComplaint.status === 'verified'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/30'
                    : selectedComplaint.status === 'pending'
                    ? 'bg-red-950 text-red-400 border border-red-900/30'
                    : 'bg-amber-950 text-amber-400 border border-amber-900/30'
                }`}>
                  {selectedComplaint.status.replace('_', ' ').toUpperCase()}
                </span>
              </div>
              <p className="text-sm font-semibold text-zinc-100 truncate mt-1">
                {selectedComplaint.location.address}
              </p>
              <p className="text-[11px] text-zinc-400 line-clamp-2">
                {selectedComplaint.textComplaint || 'No text description.'}
              </p>
            </div>
          </div>

          <div className="text-xs text-zinc-400 space-y-1 border-t md:border-t-0 md:border-l border-zinc-800/80 pt-2.5 md:pt-0 md:pl-4">
            <p>
              <span className="text-zinc-500">Reporter:</span> {selectedComplaint.citizenName}
            </p>
            <p>
              <span className="text-zinc-500">AI Trash Detection:</span>{' '}
              <span className="text-emerald-400 font-medium capitalize">
                {selectedComplaint.aiResult?.wasteType || 'General'} Waste
              </span>
            </p>
            <p>
              <span className="text-zinc-500">Coordinates:</span> {selectedComplaint.location.lat.toFixed(4)}, {selectedComplaint.location.lng.toFixed(4)}
            </p>
            {selectedComplaint.assignedEmployeeName && (
              <p>
                <span className="text-zinc-500">Assigned Expert:</span> {selectedComplaint.assignedEmployeeName}
              </p>
            )}
          </div>

          <div className="flex flex-col justify-center gap-2 border-t md:border-t-0 md:border-l border-zinc-800/80 pt-2.5 md:pt-0 md:pl-4">
            {activeRole === 'employee' && selectedComplaint.status === 'assigned' && (
              <button
                onClick={() => onUpdateComplaintStatus?.(selectedComplaint.id, 'accepted')}
                className="w-full bg-amber-500 hover:bg-amber-600 active:scale-95 text-black font-semibold py-1.5 px-3 rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <Navigation className="w-3.5 h-3.5" /> Accept & Open Route Navigation
              </button>
            )}
            {activeRole === 'employee' && selectedComplaint.status === 'accepted' && (
              <button
                onClick={() => onUpdateComplaintStatus?.(selectedComplaint.id, 'in_progress')}
                className="w-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-semibold py-1.5 px-3 rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <Navigation className="w-3.5 h-3.5 animate-bounce" /> Start Litter Cleaning Trip
              </button>
            )}
            {selectedComplaint.status === 'verified' && (
              <div className="text-xs bg-emerald-950/30 text-emerald-400 rounded-lg p-2.5 border border-emerald-900/40 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                <span>Zone verified cleaned! 50 Reward points awarded.</span>
              </div>
            )}
            {selectedComplaint.status === 'pending' && activeRole !== 'employee' && (
              <div className="text-xs bg-red-950/20 text-red-400 rounded-lg p-2.5 border border-red-900/30 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 flex-shrink-0 animate-pulse" />
                <span>Pending initial triage and crew assignment.</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
