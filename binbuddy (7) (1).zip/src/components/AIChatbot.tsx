/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, HelpCircle, Leaf, AlertTriangle, RefreshCw, Sparkles } from 'lucide-react';
import { ChatMessage } from '../types';

export default function AIChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'bot-welcome',
      sender: 'bot',
      text: "Hello! I am BinBuddy, your smart AI recycling companion. Ask me any environmental questions, seek home organic composting steps, calculate carbon footprints, or let me know if there is a litter emergency!",
      timestamp: new Date().toISOString(),
    },
  ]);
  const [inputText, setInputText] = useState<string>('');
  const [isBotLoading, setIsBotLoading] = useState<boolean>(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Carbon footprint state
  const [carbonWasteInput, setCarbonWasteInput] = useState<number>(5); // kg of waste per week
  const [carbonCalculation, setCarbonCalculation] = useState<{ co2: number; treesNeeded: number } | null>(null);

  // Scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsBotLoading(true);

    try {
      const response = await fetch('/api/ai/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg] }),
      });
      const data = await response.json();
      
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: data.text || 'Sorry, I missed that. Can you repeat?',
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (err) {
      console.error('Chat error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: "I am having a connection hiccup, but remember that clean segregation is the first step of preservation!",
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setIsBotLoading(false);
    }
  };

  const calculateCarbonFootprint = () => {
    // Basic ecological model: 1 kg of unsorted plastic/mixed garbage releases approx 1.9 kg CO2 equivalent over time.
    // Organic composting saves approx 0.8 kg CO2 per kg.
    const co2Val = parseFloat((carbonWasteInput * 1.9 * 52).toFixed(1)); // yearly CO2 kg
    const treesRequired = Math.ceil(co2Val / 22); // A mature tree absorbs ~22kg of CO2 per year
    setCarbonCalculation({
      co2: co2Val,
      treesNeeded: treesRequired,
    });
  };

  const handleEmergencyReport = () => {
    handleSendMessage("🚨 EMERGENCY REPORT: Huge toxic electronic waste spill/litter blockage near public school crossing.");
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col h-[520px] shadow-2xl" id="binbuddy-ai-chatbot">
      <div className="p-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-emerald-400" />
          <div>
            <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-1">
              BinBuddy AI Assistant <Sparkles className="w-3 h-3 text-emerald-400 fill-emerald-400" />
            </h3>
            <p className="text-[10px] text-zinc-500 font-medium">Real-time Environmental Intelligence</p>
          </div>
        </div>
        <div className="text-[10px] text-emerald-400 bg-emerald-950/30 border border-emerald-900/30 rounded px-2 py-0.5">
          Gemini Powered
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-zinc-800">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-2.5 max-w-[85%] ${m.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
          >
            <div className={`w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center border ${
              m.sender === 'user' ? 'bg-zinc-800 border-zinc-700 text-zinc-300' : 'bg-emerald-950 border-emerald-900 text-emerald-400'
            }`}>
              {m.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`rounded-2xl px-3.5 py-2.5 text-xs font-normal leading-relaxed ${
              m.sender === 'user' ? 'bg-zinc-800 text-zinc-200 rounded-tr-none' : 'bg-zinc-950 border border-zinc-850 text-zinc-300 rounded-tl-none'
            }`}>
              <p className="whitespace-pre-line">{m.text}</p>
              <span className="text-[9px] text-zinc-500 mt-1 block text-right">
                {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        {isBotLoading && (
          <div className="flex gap-2.5 max-w-[85%] mr-auto">
            <div className="w-7 h-7 rounded-full bg-emerald-950 border border-emerald-900 text-emerald-400 flex items-center justify-center animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-zinc-950 border border-zinc-850 rounded-2xl rounded-tl-none px-3.5 py-2.5 text-xs text-zinc-400 flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
              <span>Thinking...</span>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Utilities Drawer Inside Chatbot (Carbon footprint & Emergency Complaint) */}
      <div className="bg-zinc-950/80 border-t border-zinc-850 p-3 grid grid-cols-2 gap-3">
        <div className="bg-zinc-900/60 p-2.5 rounded-lg border border-zinc-800/60 text-xs">
          <p className="font-semibold text-zinc-300 flex items-center gap-1 mb-1">
            <Leaf className="w-3.5 h-3.5 text-emerald-400" /> Carbon Calculator
          </p>
          <div className="flex gap-1.5 items-center">
            <input
              type="number"
              value={carbonWasteInput}
              onChange={(e) => setCarbonWasteInput(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-12 bg-zinc-950 border border-zinc-800 rounded px-1.5 py-0.5 text-zinc-300 text-center"
            />
            <span className="text-[10px] text-zinc-500">kg trash/week</span>
            <button
              onClick={calculateCarbonFootprint}
              className="bg-emerald-600 hover:bg-emerald-700 text-black font-semibold text-[10px] px-2 py-1 rounded transition-colors ml-auto"
            >
              Calc
            </button>
          </div>
          {carbonCalculation && (
            <div className="mt-1.5 bg-zinc-950/80 rounded p-1.5 text-[10px] text-zinc-400 border border-zinc-800/40">
              CO2 Released: <strong className="text-red-400">{carbonCalculation.co2} kg/yr</strong>. Needs{' '}
              <strong className="text-emerald-400">{carbonCalculation.treesNeeded} mature trees</strong> to offset!
            </div>
          )}
        </div>

        <div className="bg-zinc-900/60 p-2.5 rounded-lg border border-zinc-800/60 text-xs flex flex-col justify-between">
          <div>
            <p className="font-semibold text-zinc-300 flex items-center gap-1 mb-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Environmental Alert
            </p>
            <p className="text-[10px] text-zinc-500 leading-normal">
              Direct hot-channel report of hazardous or blocking spills to administrative dispatch immediately.
            </p>
          </div>
          <button
            onClick={handleEmergencyReport}
            className="w-full bg-red-900/30 hover:bg-red-900/50 border border-red-500/30 text-red-300 font-semibold text-[10px] py-1 rounded transition-colors mt-2"
          >
            Simulate Emergency Report
          </button>
        </div>
      </div>

      {/* Suggested prompts list */}
      <div className="px-4 py-2 bg-zinc-900/50 border-t border-zinc-850 flex gap-2 overflow-x-auto whitespace-nowrap text-[10px]">
        <button
          onClick={() => handleSendMessage('How to compost vegetable scraps?')}
          className="bg-zinc-950 text-zinc-400 border border-zinc-800 hover:border-emerald-500/30 hover:text-emerald-300 px-2.5 py-1 rounded-full transition-colors flex items-center gap-1"
        >
          <HelpCircle className="w-3 h-3 text-emerald-400" /> Composting Help
        </button>
        <button
          onClick={() => handleSendMessage('Which bin does cardboard go to?')}
          className="bg-zinc-950 text-zinc-400 border border-zinc-800 hover:border-emerald-500/30 hover:text-emerald-300 px-2.5 py-1 rounded-full transition-colors flex items-center gap-1"
        >
          <HelpCircle className="w-3 h-3 text-emerald-400" /> Segregation Guide
        </button>
        <button
          onClick={() => handleSendMessage('What are government rewards?')}
          className="bg-zinc-950 text-zinc-400 border border-zinc-800 hover:border-emerald-500/30 hover:text-emerald-300 px-2.5 py-1 rounded-full transition-colors flex items-center gap-1"
        >
          <HelpCircle className="w-3 h-3 text-emerald-400" /> Reward Rules
        </button>
      </div>

      {/* Text Input Footer */}
      <div className="p-3 bg-zinc-950 border-t border-zinc-800 flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Ask BinBuddy AI about recycling or environment..."
          className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-200 placeholder-zinc-550 focus:outline-none focus:border-emerald-500/40"
        />
        <button
          onClick={() => handleSendMessage()}
          className="w-9 h-9 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-95 flex items-center justify-center text-black font-bold transition-all flex-shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
