import React, { useState } from 'react';
import {
  Sparkles,
  Mail,
  Lock,
  Phone,
  ArrowRight,
  ShieldAlert,
  User,
  ShieldCheck,
  Briefcase,
  UserPlus,
  Loader2,
  KeyRound,
  CheckCircle2,
  Trash2,
  Camera,
  Info
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import AIImageScanner from './AIImageScanner';

interface LoginProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [loginMethod, setLoginMethod] = useState<'email' | 'phone' | 'fastpass'>('fastpass');
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Guest scanning states
  const [guestScanLoading, setGuestScanLoading] = useState<boolean>(false);
  const [guestScanSuccess, setGuestScanSuccess] = useState<boolean>(false);
  const [lastScannedCategory, setLastScannedCategory] = useState<string>('');

  // Email form state
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');

  // Phone form state
  const [phone, setPhone] = useState<string>('');
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpCode, setOtpCode] = useState<string>('');

  // Register form state
  const [regName, setRegName] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('');
  const [regRole, setRegRole] = useState<UserRole>('citizen');

  // FastPass instant users
  const fastPassUsers = [
    {
      role: 'citizen' as UserRole,
      name: 'Rahul Sharma',
      email: 'rahul@citizen.com',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      label: 'Citizen Demo',
      badge: 'Eco Leader',
      desc: 'Report litter, play eco-quizzes, and track your cash rewards wallet.'
    },
    {
      role: 'employee' as UserRole,
      name: 'Amit Patel',
      email: 'amit@cleanup.com',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80',
      label: 'Clean Crew Demo',
      badge: 'Green Staff',
      desc: 'Claim assigned garbage incidents, view interactive routes, upload after-cleanup photos.'
    },
    {
      role: 'admin' as UserRole,
      name: 'Municipal Commissioner',
      email: 'admin@municipal.gov',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
      label: 'Admin Control',
      badge: 'System Admin',
      desc: 'Verify cleaned spots, allocate municipal funds, view AI waste hot-spots and predictions.'
    }
  ];

  // Handles standard or fastpass login
  const handleLogin = async (e?: React.FormEvent, selectedUser?: typeof fastPassUsers[0]) => {
    if (e) e.preventDefault();
    setLoading(true);
    setError(null);

    const payload: any = { method: 'standard' };

    if (selectedUser) {
      payload.email = selectedUser.email;
      payload.role = selectedUser.role;
    } else {
      if (loginMethod === 'email') {
        if (!email) {
          setError('Please fill in your email address.');
          setLoading(false);
          return;
        }
        payload.email = email;
        // In this prototype, we determine role from email domain or fallback to citizen
        if (email.includes('municipal.gov') || email.includes('admin')) {
          payload.role = 'admin';
        } else if (email.includes('cleanup') || email.includes('staff')) {
          payload.role = 'employee';
        } else {
          payload.role = 'citizen';
        }
      }
    }

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Authentication failed');
      }

      const data = await res.json();
      localStorage.setItem('binbuddy_token', data.token);
      localStorage.setItem('binbuddy_user', JSON.stringify(data.user));
      onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'Connecting to server failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handles simulate OTP sending
  const sendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone) {
      setError('Please enter a valid phone number.');
      return;
    }
    setLoading(true);
    setError(null);
    setTimeout(() => {
      setOtpSent(true);
      setLoading(false);
    }, 1200);
  };

  // Handles phone/OTP authentication
  const handleOTPVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode || otpCode.length < 4) {
      setError('Please enter the 4-digit code sent to your mobile.');
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: phone,
          method: 'phone',
          role: phone.includes('76543') ? 'admin' : phone.includes('87654') ? 'employee' : 'citizen'
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Invalid OTP verification');
      }

      const data = await res.json();
      localStorage.setItem('binbuddy_token', data.token);
      localStorage.setItem('binbuddy_user', JSON.stringify(data.user));
      onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'OTP verification failed. Please try "1234".');
    } finally {
      setLoading(false);
    }
  };

  // Handles registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail || !regPhone) {
      setError('Please complete all required fields.');
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          email: regEmail,
          phone: regPhone,
          role: regRole,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Registration failed');
      }

      const data = await res.json();
      localStorage.setItem('binbuddy_token', data.token);
      localStorage.setItem('binbuddy_user', JSON.stringify(data.user));
      onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'Registration failed. Try using a unique email.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="login_container" className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col justify-center items-center p-4 relative overflow-hidden font-sans">
      
      {/* Dynamic Grid Background Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f2937_1px,transparent_1px),linear-gradient(to_bottom,#1f2937_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none"></div>

      {/* Decorative Blur Orbs */}
      <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-teal-500/10 blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-6xl z-10 space-y-6">
        
        {/* Logo and Brand Header */}
        <div className="flex flex-col items-center text-center space-y-3 mb-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-black font-black shadow-xl shadow-emerald-500/20">
            <span className="text-3xl">B</span>
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
              BinBuddy <Sparkles className="w-5 h-5 text-emerald-400 fill-emerald-400 animate-pulse" />
            </h2>
            <p className="text-xs text-zinc-400 mt-1">Smart AI Garbage Detection & Municipal Action System</p>
          </div>
        </div>

        {/* 2-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT COLUMN: Instant Garbage AI Scanner (No Login Requirement) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-zinc-900/80 border border-zinc-800/80 rounded-2xl p-6 shadow-2xl backdrop-blur-md relative">
              <div className="flex items-center gap-3 border-b border-zinc-800/60 pb-4 mb-5">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
                    Instant AI Garbage Scanner <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 uppercase tracking-wider">No Login Required</span>
                  </h3>
                  <p className="text-[10px] text-zinc-500 mt-0.5">Test our Gemini-powered classifier immediately on live photos or template garbage presets</p>
                </div>
              </div>

              {/* Mounted Active AI Image Scanner */}
              <AIImageScanner
                onScanComplete={(image, result) => {
                  setGuestScanSuccess(true);
                  setLastScannedCategory(result.wasteType);
                }}
                isLoading={guestScanLoading}
                setIsLoading={setGuestScanLoading}
              />

              {/* Dynamic Call-to-action on successful guest classification */}
              {guestScanSuccess && (
                <div className="mt-5 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-xl p-4 animate-fadeIn">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-emerald-300">
                        Classified as {lastScannedCategory.toUpperCase()} successfully!
                      </p>
                      <p className="text-[11px] text-zinc-400 leading-relaxed">
                        To report this pile of litter on the dynamic city map, coordinate a municipal clean-up crew, and claim digital cash points inside your rewards wallet, sign in on the right panel!
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Informative Grid */}
              <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-zinc-800/60 text-[11px]">
                <div className="flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-300 font-semibold block">Civic Micro-Rewards</span>
                    <span className="text-zinc-500">Reporters and cleaners claim wallet rewards funded by Delhi municipal initiatives.</span>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-300 font-semibold block">Optimized Clean Routes</span>
                    <span className="text-zinc-500">Interactive mapping calculates best path traversal for local cleaning trucks.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Interactive Security Auth Panel */}
          <div className="lg:col-span-5">
            <div className="bg-zinc-900/80 border border-zinc-800/80 rounded-2xl p-6 md:p-8 shadow-2xl backdrop-blur-md relative">
              
              {/* Header Action Toggles (Login vs Signup) */}
              <div className="flex items-center justify-between border-b border-zinc-800/60 pb-4 mb-6">
                <h3 className="text-base font-semibold text-zinc-100">
                  {isRegistering ? 'Create Citizen Account' : 'Security Sign In'}
                </h3>
                <button
                  onClick={() => {
                    setIsRegistering(!isRegistering);
                    setError(null);
                  }}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 transition-colors"
                >
                  {isRegistering ? 'Back to Sign In' : 'New? Register Profile'} 
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              {/* Error Banner */}
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3.5 mb-5 text-xs text-red-400 flex items-start gap-2.5 animate-shake">
                  <ShieldAlert className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Security Alert</p>
                    <p className="text-[11px] opacity-90 mt-0.5">{error}</p>
                  </div>
                </div>
              )}

              {/* 1. REGISTRATION FORM FLOW */}
              {isRegistering ? (
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                      <input
                        type="text"
                        required
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="Enter full name"
                        className="w-full bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                        <input
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="e.g. rahul@email.com"
                          className="w-full bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Phone Number</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                        <input
                          type="tel"
                          required
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="e.g. +91 98765 43210"
                          className="w-full bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">System Persona</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setRegRole('citizen')}
                        className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                          regRole === 'citizen'
                            ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                            : 'border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        <User className="w-4 h-4" /> Citizen Reporter
                      </button>
                      <button
                        type="button"
                        onClick={() => setRegRole('employee')}
                        className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                          regRole === 'employee'
                            ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                            : 'border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        <Briefcase className="w-4 h-4" /> Clean Crew Staff
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-black font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 transition-all disabled:opacity-50 mt-2"
                  >
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                    Complete Citizen Registration
                  </button>
                </form>
              ) : (
                
                // 2. SIGN IN FLOWS
                <div className="space-y-6">
                  
                  {/* Login Method Tab Toggles */}
                  <div className="grid grid-cols-3 gap-1 bg-zinc-950 border border-zinc-800/80 p-1 rounded-xl">
                    <button
                      onClick={() => {
                        setLoginMethod('fastpass');
                        setError(null);
                      }}
                      className={`py-2 rounded-lg text-[11px] font-bold transition-all ${
                        loginMethod === 'fastpass' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-500 hover:text-zinc-300'
                      }`}
                    >
                      💨 Fast Pass
                    </button>
                    <button
                      onClick={() => {
                        setLoginMethod('email');
                        setError(null);
                      }}
                      className={`py-2 rounded-lg text-[11px] font-bold transition-all ${
                        loginMethod === 'email' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-500 hover:text-zinc-300'
                      }`}
                    >
                      ✉️ Email Pass
                    </button>
                    <button
                      onClick={() => {
                        setLoginMethod('phone');
                        setError(null);
                      }}
                      className={`py-2 rounded-lg text-[11px] font-bold transition-all ${
                        loginMethod === 'phone' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-500 hover:text-zinc-300'
                      }`}
                    >
                      📱 Phone OTP
                    </button>
                  </div>

                  {/* A. FAST PASS VIEW (Demonstration quick access) */}
                  {loginMethod === 'fastpass' && (
                    <div className="space-y-4">
                      <div className="bg-zinc-950/40 p-3 rounded-xl border border-zinc-850/60">
                        <p className="text-[10px] text-zinc-400 leading-relaxed font-medium">
                          Select one of the simulated personnel identities below to securely bypass standard password criteria for testing and immediate evaluation.
                        </p>
                      </div>

                      <div className="space-y-3">
                        {fastPassUsers.map((user) => (
                          <button
                            key={user.email}
                            onClick={() => handleLogin(undefined, user)}
                            className="w-full text-left bg-zinc-950/60 border border-zinc-850 hover:border-emerald-500/40 hover:bg-zinc-900/80 p-3.5 rounded-xl flex items-center gap-3 transition-all group"
                          >
                            <img src={user.avatar} className="w-10 h-10 rounded-full border border-zinc-800 object-cover" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-zinc-100 group-hover:text-emerald-400 transition-colors">
                                  {user.name}
                                </span>
                                <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-zinc-800 border border-zinc-700/80 text-zinc-400 uppercase">
                                  {user.badge}
                                </span>
                              </div>
                              <p className="text-[10px] text-zinc-500 truncate mt-0.5">{user.email}</p>
                              <p className="text-[10px] text-zinc-400 leading-normal mt-1 italic font-medium">
                                {user.desc}
                              </p>
                            </div>
                            <ArrowRight className="w-4 h-4 text-zinc-600 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* B. EMAIL PASSWORD VIEW */}
                  {loginMethod === 'email' && (
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Email Address</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                          <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="e.g. rahul@citizen.com, amit@cleanup.com"
                            className="w-full bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none transition-all"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center">
                          <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Password</label>
                          <button
                            type="button"
                            onClick={() => alert("Simulating recovery: A link has been dispatched to your email address.")}
                            className="text-[10px] text-emerald-400 hover:underline"
                          >
                            Forgot?
                          </button>
                        </div>
                        <div className="relative">
                          <Lock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                          <input
                            type="password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none transition-all"
                          />
                        </div>
                      </div>

                      <div className="bg-zinc-950/50 p-3 rounded-lg text-[10px] text-zinc-500 leading-normal border border-zinc-850">
                        💡 <strong className="text-zinc-400">Credential Hint:</strong> Use <code className="text-emerald-400 bg-zinc-900 px-1 py-0.5 rounded">rahul@citizen.com</code>, <code className="text-emerald-400 bg-zinc-900 px-1 py-0.5 rounded">amit@cleanup.com</code>, or <code className="text-emerald-400 bg-zinc-900 px-1 py-0.5 rounded">admin@municipal.gov</code> with any password.
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-black font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 transition-all disabled:opacity-50"
                      >
                        {loading ? <Loader2 className="w-4.5 h-4.5 animate-spin" /> : <KeyRound className="w-4 h-4" />}
                        Authenticate Securely
                      </button>
                    </form>
                  )}

                  {/* C. PHONE OTP VIEW */}
                  {loginMethod === 'phone' && (
                    <div className="space-y-4">
                      {!otpSent ? (
                        <form onSubmit={sendOTP} className="space-y-4">
                          <div className="space-y-1.5">
                            <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Phone Number</label>
                            <div className="relative">
                              <Phone className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                              <input
                                type="tel"
                                required
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                                placeholder="e.g. +91 98765 43210"
                                className="w-full bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none transition-all"
                              />
                            </div>
                          </div>

                          <div className="bg-zinc-950/50 p-3 rounded-lg text-[10px] text-zinc-500 leading-normal border border-zinc-850">
                            💡 <strong className="text-zinc-400">Verification Hint:</strong> Standard registered citizen phone is <code className="text-emerald-400 bg-zinc-900 px-1 py-0.5 rounded">+91 98765 43210</code>. Enter this to trigger an instant OTP simulation.
                          </div>

                          <button
                            type="submit"
                            disabled={loading}
                            className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-black font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 transition-all disabled:opacity-50"
                          >
                            {loading ? <Loader2 className="w-4.5 h-4.5 animate-spin" /> : <Phone className="w-4 h-4" />}
                            Send Verification Code SMS
                          </button>
                        </form>
                      ) : (
                        <form onSubmit={handleOTPVerify} className="space-y-4">
                          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3.5 text-xs text-emerald-400 flex items-start gap-2.5">
                            <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400 flex-shrink-0" />
                            <div>
                              <p className="font-semibold">Simulated SMS Transpatched</p>
                              <p className="text-[10px] opacity-90 mt-0.5">
                                We've dispatched a 4-digit code to <strong className="text-white">{phone}</strong>. Use code <strong className="text-white">1234</strong> to simulate instant verification.
                              </p>
                            </div>
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">Enter verification OTP Code</label>
                            <input
                              type="text"
                              maxLength={4}
                              required
                              value={otpCode}
                              onChange={(e) => setOtpCode(e.target.value)}
                              placeholder="1234"
                              className="w-full text-center bg-zinc-950/60 border border-zinc-800/85 hover:border-zinc-700/80 focus:border-emerald-500/40 rounded-xl py-3 text-lg font-mono tracking-widest text-emerald-400 focus:outline-none transition-all placeholder-zinc-700"
                            />
                          </div>

                          <div className="flex justify-between items-center">
                            <button
                              type="button"
                              onClick={() => setOtpSent(false)}
                              className="text-[10px] text-zinc-500 hover:text-zinc-300"
                            >
                              Change Number
                            </button>
                            <button
                              type="button"
                              onClick={() => alert("OTP Resent! Simulating brand-new secure dispatch.")}
                              className="text-[10px] text-emerald-400 hover:underline"
                            >
                              Resend Code
                            </button>
                          </div>

                          <button
                            type="submit"
                            disabled={loading}
                            className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-black font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 transition-all disabled:opacity-50"
                          >
                            {loading ? <Loader2 className="w-4.5 h-4.5 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                            Verify OTP & Login
                          </button>
                        </form>
                      )}
                    </div>
                  )}

                </div>
              )}
            </div>
          </div>

        </div>

        {/* Outer Minimal Footer Credential Summary */}
        <p className="text-center text-[10px] text-zinc-600 font-medium pt-4">
          Protected by BinBuddy Federated Secure Access Protocols. City Municipal Delhi &copy; 2026.
        </p>

      </div>
    </div>
  );
}
