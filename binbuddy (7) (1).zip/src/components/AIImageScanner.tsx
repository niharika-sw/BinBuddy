/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  RefreshCw,
  Sparkles,
  CheckCircle2,
  Video,
  FlipHorizontal,
  AlertCircle,
  FileUp,
  Loader2,
  X
} from 'lucide-react';
import { AIResult, WasteType } from '../types';

interface AIImageScannerProps {
  onScanComplete: (image: string, result: AIResult) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const SAMPLE_IMAGES = [
  {
    name: 'Plastic Heap',
    type: 'plastic',
    url: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Broken Glass',
    type: 'glass',
    url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Organic Dump',
    type: 'organic',
    url: 'https://images.unsplash.com/photo-1503596476-1c12a8ba09a9?auto=format&fit=crop&w=400&q=80',
  },
];

export default function AIImageScanner({ onScanComplete, isLoading, setIsLoading }: AIImageScannerProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [detection, setDetection] = useState<AIResult | null>(null);
  const [scanMode, setScanMode] = useState<'upload' | 'camera'>('upload');
  const [isCameraStarting, setIsCameraStarting] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Stop camera stream on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setSelectedImage(base64);
        triggerAIDetection(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const selectSampleImage = (url: string, type: string) => {
    setSelectedImage(url);
    triggerAIDetection(url, type);
  };

  const startCamera = async (currentFacing: 'user' | 'environment' = facingMode) => {
    setIsCameraStarting(true);
    setCameraError(null);
    stopCamera();

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: currentFacing,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error('Error starting camera:', err);
      let errorMsg = 'Could not access camera. Please ensure permissions are granted.';
      if (err.name === 'NotAllowedError') {
        errorMsg = 'Camera access was denied. Please grant permission in your browser or iframe settings.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        errorMsg = 'No camera hardware found on this system.';
      } else if (window.location.protocol !== 'https:' && window.location.hostname !== 'localhost') {
        errorMsg = 'Webcam scanning requires a secure context (HTTPS) or localhost.';
      }
      setCameraError(errorMsg);
    } finally {
      setIsCameraStarting(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // If user front camera, apply mirror flip to final snapshot
        if (facingMode === 'user') {
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
        }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL('image/jpeg', 0.85);
        setSelectedImage(base64);
        stopCamera();
        setScanMode('upload'); // Reset mode state to upload view to show preview
        triggerAIDetection(base64);
      }
    }
  };

  const handleModeChange = (mode: 'upload' | 'camera') => {
    setScanMode(mode);
    setCameraError(null);
    if (mode === 'camera') {
      // Allow DOM to settle before querying video element
      setTimeout(() => startCamera(facingMode), 100);
    } else {
      stopCamera();
    }
  };

  const toggleCameraFace = () => {
    const nextFacing = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextFacing);
    startCamera(nextFacing);
  };

  const triggerAIDetection = async (imageSrc: string, typeHint?: string) => {
    setIsLoading(true);
    setDetection(null);
    try {
      const response = await fetch('/api/ai/detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base64Image: imageSrc.startsWith('http') ? 'MOCK_URL_IMAGE' : imageSrc,
          wasteTypeHint: typeHint,
        }),
      });
      const result: AIResult = await response.json();
      setDetection(result);
      onScanComplete(imageSrc, result);
    } catch (err) {
      console.error('Error scanning waste:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const resetScanner = () => {
    setSelectedImage(null);
    setDetection(null);
    stopCamera();
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getWasteBadgeStyle = (type: WasteType) => {
    const styles: Record<WasteType, string> = {
      plastic: 'bg-blue-900/40 text-blue-300 border-blue-500/30',
      paper: 'bg-emerald-900/40 text-emerald-300 border-emerald-500/30',
      glass: 'bg-amber-900/40 text-amber-300 border-amber-500/30',
      metal: 'bg-red-900/40 text-red-300 border-red-500/30',
      organic: 'bg-purple-900/40 text-purple-300 border-purple-500/30',
      e_waste: 'bg-slate-800 text-slate-300 border-slate-600/30',
      mixed: 'bg-orange-900/40 text-orange-300 border-orange-500/30',
    };
    return styles[type] || 'bg-zinc-800 text-zinc-300 border-zinc-700';
  };

  return (
    <div className="bg-zinc-900/80 border border-zinc-800/80 rounded-2xl p-6 backdrop-blur-md shadow-xl" id="ai-image-scanner-container">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-semibold text-zinc-100 font-sans tracking-tight">AI Waste Classifier</h2>
        </div>
        {selectedImage && (
          <button
            onClick={resetScanner}
            className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Reset Scanner
          </button>
        )}
      </div>

      {/* Mode Select Tabs (only visible when no image is active) */}
      {!selectedImage && (
        <div className="grid grid-cols-2 gap-1 bg-zinc-950/80 border border-zinc-850 p-1 rounded-xl mb-4">
          <button
            onClick={() => handleModeChange('upload')}
            className={`py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              scanMode === 'upload' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <FileUp className="w-3.5 h-3.5" /> File Upload & Presets
          </button>
          <button
            onClick={() => handleModeChange('camera')}
            className={`py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              scanMode === 'camera' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Video className="w-3.5 h-3.5" /> Live Camera Scan
          </button>
        </div>
      )}

      {/* Main View Area */}
      {!selectedImage ? (
        <div>
          {/* UPLOAD MODE VIEW */}
          {scanMode === 'upload' && (
            <div className="space-y-6">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-800 hover:border-emerald-500/50 bg-zinc-950/50 rounded-xl p-8 text-center cursor-pointer transition-all duration-300 group"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-full bg-zinc-900 flex items-center justify-center mx-auto mb-3 border border-zinc-800 group-hover:scale-110 group-hover:border-emerald-500/30 transition-all duration-300">
                  <Camera className="w-6 h-6 text-zinc-400 group-hover:text-emerald-400" />
                </div>
                <p className="text-sm font-medium text-zinc-300">Take Photo or Upload Image</p>
                <p className="text-xs text-zinc-500 mt-1">Supports PNG, JPG, JPEG up to 10MB</p>
              </div>

              <div>
                <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2.5">
                  Or Select a Preset Garbage Sample
                </p>
                <div className="grid grid-cols-3 gap-3">
                  {SAMPLE_IMAGES.map((img) => (
                    <button
                      key={img.name}
                      onClick={() => selectSampleImage(img.url, img.type)}
                      className="group relative h-20 rounded-lg overflow-hidden border border-zinc-800 hover:border-zinc-700 active:scale-95 transition-all"
                    >
                      <img
                        src={img.url}
                        alt={img.name}
                        className="w-full h-full object-cover brightness-75 group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-2">
                        <span className="text-[10px] font-medium text-zinc-300 group-hover:text-zinc-100">
                          {img.name}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* LIVE CAMERA MODE VIEW */}
          {scanMode === 'camera' && (
            <div className="space-y-4">
              {cameraError ? (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex flex-col items-center text-center space-y-3">
                  <AlertCircle className="w-8 h-8 text-red-400" />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-red-300">Webcam Inaccessible</p>
                    <p className="text-[11px] text-zinc-400 max-w-sm leading-relaxed">{cameraError}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => startCamera(facingMode)}
                      className="bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-[11px] font-bold px-3 py-1.5 rounded-lg transition-all"
                    >
                      Retry Camera
                    </button>
                    <button
                      onClick={() => handleModeChange('upload')}
                      className="bg-emerald-500 hover:bg-emerald-600 text-black text-[11px] font-bold px-3 py-1.5 rounded-lg transition-all"
                    >
                      Use File Upload Instead
                    </button>
                  </div>
                </div>
              ) : (
                <div className="relative aspect-video rounded-xl overflow-hidden border border-zinc-800 bg-black shadow-2xl">
                  {/* Video Viewfinder */}
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                  />

                  {/* Camera Starting State */}
                  {isCameraStarting && (
                    <div className="absolute inset-0 bg-zinc-950 flex flex-col items-center justify-center space-y-2">
                      <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
                      <p className="text-xs font-semibold text-zinc-300">Initializing camera feed...</p>
                      <p className="text-[10px] text-zinc-500">Acquiring video authorization</p>
                    </div>
                  )}

                  {/* Visual Viewfinder Overlay Guide */}
                  {!isCameraStarting && (
                    <>
                      {/* Holographic scanner line animation */}
                      <div className="absolute w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_rgba(16,185,129,0.8)] animate-scan top-0 left-0 pointer-events-none z-10" />

                      {/* Corner Target Alignment Reticles */}
                      <div className="absolute top-4 left-4 w-5 h-5 border-t-2 border-l-2 border-emerald-400 pointer-events-none opacity-80" />
                      <div className="absolute top-4 right-4 w-5 h-5 border-t-2 border-r-2 border-emerald-400 pointer-events-none opacity-80" />
                      <div className="absolute bottom-4 left-4 w-5 h-5 border-b-2 border-l-2 border-emerald-400 pointer-events-none opacity-80" />
                      <div className="absolute bottom-4 right-4 w-5 h-5 border-b-2 border-r-2 border-emerald-400 pointer-events-none opacity-80" />

                      {/* Central Crosshair target */}
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30">
                        <div className="w-10 h-10 border border-dashed border-emerald-400 rounded-full flex items-center justify-center">
                          <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                        </div>
                      </div>

                      {/* Live Camera Badge */}
                      <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-zinc-950/80 border border-zinc-800 text-[10px] text-zinc-300 font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-md pointer-events-none shadow-md">
                        <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                        LIVE SCANNING VIEWPORT
                      </div>

                      {/* Device Facing Mode Selector & Control Toolbar inside Video */}
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-zinc-950/90 border border-zinc-800 p-2 rounded-xl backdrop-blur-md shadow-xl max-w-[90%] z-20">
                        <button
                          type="button"
                          onClick={toggleCameraFace}
                          className="p-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-lg text-zinc-300 hover:text-emerald-400 active:scale-95 transition-all"
                          title="Flip Camera View"
                        >
                          <FlipHorizontal className="w-4 h-4" />
                        </button>
                        
                        <button
                          type="button"
                          onClick={capturePhoto}
                          className="bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-black font-extrabold text-xs px-5 py-2 rounded-lg flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all"
                        >
                          <Camera className="w-4 h-4" /> Snapshot & Classify
                        </button>

                        <button
                          type="button"
                          onClick={() => handleModeChange('upload')}
                          className="p-2 bg-zinc-900 hover:bg-red-500/20 border border-zinc-800 hover:border-red-500/30 rounded-lg text-zinc-400 hover:text-red-400 active:scale-95 transition-all"
                          title="Close Camera"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* CLASSIFICATION RESULT PREVIEW VIEW */
        <div className="space-y-4">
          <div className="relative aspect-video rounded-xl overflow-hidden border border-zinc-800 bg-black">
            <img src={selectedImage} alt="Scanned waste" className="w-full h-full object-cover" referrerPolicy="no-referrer" />

            {isLoading && (
              <div className="absolute inset-0 bg-zinc-950/80 backdrop-blur-sm flex flex-col items-center justify-center">
                <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin mb-2" />
                <p className="text-xs font-medium text-zinc-300">AI Analyzing Image...</p>
                <p className="text-[10px] text-zinc-500 mt-0.5">Detecting bounding boxes & litter density</p>
              </div>
            )}

            {/* AI Bounding Boxes */}
            {!isLoading && detection && detection.boxes.map((box, idx) => (
              <div
                key={idx}
                className="absolute border-2 border-emerald-500/80 bg-emerald-500/10 rounded"
                style={{
                  left: `${box.x}%`,
                  top: `${box.y}%`,
                  width: `${box.w}%`,
                  height: `${box.h}%`,
                }}
              >
                <span className="absolute -top-5 left-0 bg-emerald-500 text-black text-[9px] font-bold px-1 rounded shadow-md whitespace-nowrap z-10">
                  {box.label} ({Math.round(box.confidence * 100)}%)
                </span>
              </div>
            ))}
          </div>

          {!isLoading && detection && (
            <div className="bg-zinc-950/60 rounded-xl p-4 border border-zinc-800/40 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-zinc-500">AI Classified Category</p>
                  <span className={`inline-block mt-1 px-2.5 py-0.5 text-xs font-semibold rounded-full border ${getWasteBadgeStyle(detection.wasteType)}`}>
                    {detection.wasteType.toUpperCase()} ({Math.round(detection.confidence * 100)}%)
                  </span>
                </div>
                <div className="text-right">
                  <p className="text-xs text-zinc-500">Litter Density</p>
                  <span className={`inline-block mt-1 text-xs font-medium ${detection.density === 'high' ? 'text-red-400' : detection.density === 'medium' ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {detection.density.toUpperCase()}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-zinc-800/40 text-xs">
                <div>
                  <span className="text-zinc-500 block">Estimated Area:</span>
                  <span className="text-zinc-300 font-medium">{detection.area}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Estimated Trash:</span>
                  <span className="text-zinc-300 font-medium">{detection.quantity}</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-emerald-400/90 bg-emerald-950/20 border border-emerald-900/30 rounded-lg p-2 mt-2">
                <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                <span>AI results attached to report. Ready to save!</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
