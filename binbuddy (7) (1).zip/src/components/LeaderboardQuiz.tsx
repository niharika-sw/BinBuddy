/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Trophy, Award, Wallet, Gift, CheckCircle2, XCircle, ArrowUpRight, HelpCircle, BookOpen, Star } from 'lucide-react';
import { LeaderboardEntry, QuizQuestion, WalletData } from '../types';

interface LeaderboardQuizProps {
  userPoints: number;
  onPointsRedeemed: (deducted: number, title: string) => void;
}

const CAMPAIGN_TIPS = [
  { title: 'Swachh Bharat Cleanliness', desc: 'Separate dry plastic and paper from wet organic kitchen waste at home.', tag: 'Government Guide' },
  { title: 'Home Composting Tips', desc: 'Layer organic kitchen peels with dry leaves or soil in an aerated composting box.', tag: 'Organic Composting' },
  { title: 'E-Waste Solutions', desc: 'Do not throw away cell batteries or chargers with house rubbish. Drop them to collection booths.', tag: 'Heavy Metal Protection' },
];

export default function LeaderboardQuiz({ userPoints, onPointsRedeemed }: LeaderboardQuizProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [quizzes, setQuizzes] = useState<QuizQuestion[]>([]);
  const [wallet, setWallet] = useState<WalletData | null>(null);

  // Quiz taking state
  const [activeQuizIndex, setActiveQuizIndex] = useState<number>(0);
  const [selectedAnswerIndex, setSelectedAnswerIndex] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);
  const [quizFeedback, setQuizFeedback] = useState<string>('');
  
  // Tab control
  const [activeTab, setActiveTab] = useState<'wallet' | 'leaderboard' | 'quiz'>('quiz');

  useEffect(() => {
    fetchLeaderboard();
    fetchQuizzes();
    fetchWallet();
  }, [userPoints]);

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch('/api/leaderboard');
      const data = await res.json();
      setLeaderboard(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchQuizzes = async () => {
    try {
      const res = await fetch('/api/quizzes');
      const data = await res.json();
      setQuizzes(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchWallet = async () => {
    try {
      const res = await fetch('/api/rewards/wallet');
      const data = await res.json();
      setWallet(data);
    } catch (err) {
      console.error(err);
    }
  };

  const checkAnswer = () => {
    if (selectedAnswerIndex === null || quizzes.length === 0) return;
    
    const currentQuestion = quizzes[activeQuizIndex];
    if (selectedAnswerIndex === currentQuestion.correctAnswerIndex) {
      setScore((prev) => prev + 1);
      setQuizFeedback(`Correct! ${currentQuestion.explanation}`);
    } else {
      setQuizFeedback(`Incorrect. The correct answer was: "${currentQuestion.options[currentQuestion.correctAnswerIndex]}". ${currentQuestion.explanation}`);
    }
    setIsAnswerChecked(true);
  };

  const nextQuestion = () => {
    setSelectedAnswerIndex(null);
    setIsAnswerChecked(false);
    setQuizFeedback('');
    if (activeQuizIndex + 1 < quizzes.length) {
      setActiveQuizIndex((prev) => prev + 1);
    } else {
      setQuizFinished(true);
      // Give eco bonus points on backend
      onPointsRedeemed(-100, 'Eco Certification Quiz Reward Bonus');
    }
  };

  const restartQuiz = () => {
    setActiveQuizIndex(0);
    setSelectedAnswerIndex(null);
    setIsAnswerChecked(false);
    setScore(0);
    setQuizFinished(false);
    setQuizFeedback('');
  };

  const redeemReward = async (title: string, points: number) => {
    if (userPoints < points) {
      alert("Insufficient reward points balance!");
      return;
    }
    try {
      const res = await fetch('/api/rewards/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, points }),
      });
      const data = await res.json();
      if (data.success) {
        onPointsRedeemed(points, title);
        fetchWallet();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const getRankBadgeColor = (rank: number) => {
    if (rank === 1) return 'bg-amber-500 text-black border-amber-300';
    if (rank === 2) return 'bg-zinc-300 text-black border-zinc-100';
    if (rank === 3) return 'bg-amber-700 text-white border-amber-600';
    return 'bg-zinc-800 text-zinc-400 border-zinc-750';
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col h-[520px] shadow-2xl" id="binbuddy-leaderboard-quiz">
      <div className="flex bg-zinc-950 border-b border-zinc-800 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('quiz')}
          className={`flex-1 py-3 border-b-2 flex items-center justify-center gap-1.5 transition-all ${activeTab === 'quiz' ? 'border-emerald-500 text-emerald-400 bg-zinc-900/40' : 'border-transparent text-zinc-400 hover:text-zinc-200'}`}
        >
          <BookOpen className="w-3.5 h-3.5" /> Environmental Quiz
        </button>
        <button
          onClick={() => setActiveTab('leaderboard')}
          className={`flex-1 py-3 border-b-2 flex items-center justify-center gap-1.5 transition-all ${activeTab === 'leaderboard' ? 'border-emerald-500 text-emerald-400 bg-zinc-900/40' : 'border-transparent text-zinc-400 hover:text-zinc-200'}`}
        >
          <Trophy className="w-3.5 h-3.5" /> Leaderboard
        </button>
        <button
          onClick={() => setActiveTab('wallet')}
          className={`flex-1 py-3 border-b-2 flex items-center justify-center gap-1.5 transition-all ${activeTab === 'wallet' ? 'border-emerald-500 text-emerald-400 bg-zinc-900/40' : 'border-transparent text-zinc-400 hover:text-zinc-200'}`}
        >
          <Wallet className="w-3.5 h-3.5" /> Rewards Wallet ({userPoints} pts)
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 scrollbar-thin scrollbar-thumb-zinc-800">
        {/* TAB 1: ENVIRONMENTAL QUIZ & CAMPAIGNS */}
        {activeTab === 'quiz' && (
          <div className="space-y-4">
            {quizzes.length > 0 && !quizFinished ? (
              <div className="bg-zinc-950/60 rounded-xl p-4 border border-zinc-850/60 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold tracking-wider text-emerald-400 uppercase bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/30">
                    Campaign Quiz: Question {activeQuizIndex + 1}/{quizzes.length}
                  </span>
                  <span className="text-[10px] text-zinc-500 font-medium">Score: {score}</span>
                </div>

                <h4 className="text-sm font-semibold text-zinc-100 leading-normal">
                  {quizzes[activeQuizIndex].question}
                </h4>

                <div className="space-y-2 pt-2">
                  {quizzes[activeQuizIndex].options.map((opt, oIdx) => (
                    <button
                      key={oIdx}
                      disabled={isAnswerChecked}
                      onClick={() => setSelectedAnswerIndex(oIdx)}
                      className={`w-full text-left p-3 rounded-lg border text-xs font-medium transition-all flex items-start gap-2.5 ${
                        selectedAnswerIndex === oIdx
                          ? 'border-emerald-500 bg-emerald-950/20 text-emerald-300'
                          : 'border-zinc-800 bg-zinc-900/40 hover:bg-zinc-900 text-zinc-300'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full bg-zinc-950 border border-zinc-800 flex items-center justify-center flex-shrink-0 text-[10px] font-semibold text-zinc-400 group-hover:border-emerald-500">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span>{opt}</span>
                    </button>
                  ))}
                </div>

                {isAnswerChecked && (
                  <div className={`p-3 rounded-lg text-xs leading-relaxed border ${
                    selectedAnswerIndex === quizzes[activeQuizIndex].correctAnswerIndex
                      ? 'bg-emerald-950/40 border-emerald-900/30 text-emerald-300'
                      : 'bg-red-950/20 border-red-900/20 text-red-300'
                  }`}>
                    <div className="flex items-center gap-1.5 font-bold mb-1">
                      {selectedAnswerIndex === quizzes[activeQuizIndex].correctAnswerIndex ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <XCircle className="w-4 h-4" />
                      )}
                      <span>Explanation:</span>
                    </div>
                    <p className="text-[11px] font-medium leading-relaxed">{quizFeedback}</p>
                  </div>
                )}

                <div className="pt-2 flex justify-end">
                  {!isAnswerChecked ? (
                    <button
                      disabled={selectedAnswerIndex === null}
                      onClick={checkAnswer}
                      className="bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-black font-semibold text-xs px-4 py-2 rounded-lg transition-all disabled:opacity-40"
                    >
                      Check Answer
                    </button>
                  ) : (
                    <button
                      onClick={nextQuestion}
                      className="bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-zinc-200 font-semibold text-xs px-4 py-2 rounded-lg transition-all"
                    >
                      {activeQuizIndex + 1 < quizzes.length ? 'Next Question' : 'Finish Quiz'}
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-zinc-950/80 rounded-xl p-5 border border-zinc-850 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-950/40 border border-emerald-900 flex items-center justify-center mx-auto text-emerald-400 animate-bounce">
                  <Award className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-zinc-100">Cleanliness Certificate Unlocked!</h4>
                  <p className="text-xs text-zinc-400 max-w-sm mx-auto mt-1 leading-relaxed">
                    You scored <strong className="text-emerald-400">{score}/{quizzes.length}</strong>! A government certification bonus of <strong className="text-emerald-400">+100 Reward points</strong> has been deposited.
                  </p>
                </div>
                <div className="border border-emerald-900/30 bg-emerald-950/10 rounded-lg p-3.5 max-w-xs mx-auto text-[10px] text-zinc-400 leading-normal">
                  🎖️ <strong className="text-zinc-200 font-semibold">BinBuddy Certified Cleanliness Pioneer</strong>
                  <p className="mt-0.5 font-medium">Rahul Sharma has successfully passed Swachh Bharat recycling criteria.</p>
                </div>
                <button
                  onClick={restartQuiz}
                  className="bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-black font-semibold text-xs px-4 py-2 rounded-lg transition-all"
                >
                  Retake Quiz
                </button>
              </div>
            )}

            {/* Campaign info section */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                Recycling Campaigns & Campaigns Tips
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {CAMPAIGN_TIPS.map((tip, idx) => (
                  <div key={idx} className="bg-zinc-950/40 p-3 rounded-lg border border-zinc-850">
                    <span className="text-[9px] font-semibold text-emerald-400 uppercase tracking-wider bg-emerald-950/30 px-1.5 py-0.5 rounded border border-emerald-900/20">
                      {tip.tag}
                    </span>
                    <h5 className="text-xs font-semibold text-zinc-200 mt-2">{tip.title}</h5>
                    <p className="text-[10px] text-zinc-400 mt-1 leading-relaxed">{tip.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LEADERBOARD */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                National Environmental Leaderboard
              </p>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/20 px-2 py-0.5 rounded">
                Updated Daily
              </span>
            </div>

            <div className="bg-zinc-950/50 rounded-xl border border-zinc-850 overflow-hidden divide-y divide-zinc-850">
              {leaderboard.map((user) => (
                <div key={user.userId} className="flex items-center justify-between p-3.5 hover:bg-zinc-900/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-md border flex items-center justify-center text-xs font-bold ${getRankBadgeColor(user.rank)}`}>
                      {user.rank}
                    </span>
                    <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full border border-zinc-800 object-cover" />
                    <div>
                      <p className="text-xs font-semibold text-zinc-200">{user.name}</p>
                      <p className="text-[9px] text-zinc-500 flex items-center gap-1 mt-0.5">
                        <Star className="w-3 h-3 text-amber-400 fill-amber-400" />{' '}
                        {user.role === 'employee' ? 'Municipal Expert' : `Eco Level ${Math.ceil(user.points / 250) || 1}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-emerald-400">{user.points} pts</span>
                    <span className="text-[9px] text-zinc-500 block">Total actions verified</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: REWARDS WALLET & REDEMPTIONS */}
        {activeTab === 'wallet' && (
          <div className="space-y-4">
            <div className="bg-zinc-950/70 border border-zinc-850 rounded-xl p-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-zinc-500">Your Redeemable Balance</p>
                <div className="flex items-center gap-2 mt-1">
                  <Wallet className="w-5 h-5 text-emerald-400" />
                  <span className="text-2xl font-bold text-zinc-100">{userPoints}</span>
                  <span className="text-xs text-zinc-400">Eco Points</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-900/30 rounded px-2 py-0.5 block">
                  Level {Math.ceil(userPoints / 250) || 1} Warrior
                </span>
                <span className="text-[9px] text-zinc-500 mt-1 block">Earn 50 points per report</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-2.5">
                <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Available Eco Rewards Coupons
                </p>
                
                <div className="space-y-2">
                  {[
                    { title: 'Eco Canvas Carry Bag Discount', cost: 150, desc: 'Receive free shipping and Rs.100 voucher.' },
                    { title: 'Plant A Sapling Contribution', cost: 300, desc: 'Government campaign plants 1 real sapling in your name.' },
                    { title: 'Free Swachh Compost Kit', cost: 400, desc: 'Home composting fertilizer kit mailed free.' },
                  ].map((coupon) => (
                    <div key={coupon.title} className="bg-zinc-950/50 rounded-xl p-3 border border-zinc-850 flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <h5 className="text-xs font-bold text-zinc-200">{coupon.title}</h5>
                        <p className="text-[10px] text-zinc-400">{coupon.desc}</p>
                      </div>
                      <button
                        onClick={() => redeemReward(coupon.title, coupon.cost)}
                        disabled={userPoints < coupon.cost}
                        className="bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 text-black font-semibold text-[10px] px-2.5 py-1.5 rounded transition-all whitespace-nowrap"
                      >
                        Redeem ({coupon.cost} pts)
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5">
                <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Eco Points Activity History
                </p>

                <div className="bg-zinc-950/30 border border-zinc-850 rounded-xl max-h-[170px] overflow-y-auto divide-y divide-zinc-850">
                  {wallet?.transactions.map((tx) => (
                    <div key={tx.id} className="p-2.5 flex justify-between items-center text-[11px] hover:bg-zinc-900/20 transition-colors">
                      <div className="truncate pr-2">
                        <p className="font-semibold text-zinc-300 truncate">{tx.title}</p>
                        <span className="text-[9px] text-zinc-500">{new Date(tx.date).toLocaleDateString()}</span>
                      </div>
                      <span className={`font-bold flex items-center gap-0.5 ${tx.type === 'earn' ? 'text-emerald-400' : 'text-red-400'}`}>
                        {tx.type === 'earn' ? '+' : ''}{tx.points}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
