/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'citizen' | 'employee' | 'admin';

export type WasteType = 'plastic' | 'paper' | 'glass' | 'metal' | 'organic' | 'e_waste' | 'mixed';

export type ComplaintStatus =
  | 'pending'
  | 'assigned'
  | 'accepted'
  | 'in_progress'
  | 'completed'
  | 'waiting_verification'
  | 'verified'
  | 'rejected';

export interface BoundingBox {
  label: string;
  confidence: number;
  x: number; // percentage from left 0-100
  y: number; // percentage from top 0-100
  w: number; // percentage of width 0-100
  h: number; // percentage of height 0-100
}

export interface AIResult {
  wasteType: WasteType;
  confidence: number;
  area: string;
  quantity: string;
  density: string;
  boxes: BoundingBox[];
}

export interface LocationData {
  lat: number;
  lng: number;
  address: string;
  city: string;
  state: string;
  pincode: string;
}

export interface Complaint {
  id: string;
  citizenId: string;
  citizenName: string;
  image: string;
  voiceComplaint?: string;
  textComplaint?: string;
  location: LocationData;
  timestamp: string;
  aiResult?: AIResult;
  status: ComplaintStatus;
  assignedEmployeeId?: string;
  assignedEmployeeName?: string;
  beforeImage?: string;
  afterImage?: string;
  verifiedAt?: string;
  rewardPoints?: number;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string;
  rewardPoints: number;
  complaintsCount: number;
  level: number;
  achievements: string[];
}

export interface LeaderboardEntry {
  userId: string;
  name: string;
  avatar: string;
  role: UserRole;
  points: number;
  rank: number;
}

export interface RewardTransaction {
  id: string;
  title: string;
  points: number;
  type: 'earn' | 'redeem';
  date: string;
}

export interface WalletData {
  balance: number;
  transactions: RewardTransaction[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface Hotspot {
  id: string;
  lat: number;
  lng: number;
  intensity: number; // 1-10
  city: string;
  complaintsCount: number;
}

export interface PredictionData {
  areaName: string;
  currentPollutionIndex: number; // 0-100
  predictedPollutionNextWeek: number; // 0-100
  mostCommonWasteType: WasteType;
  recommendedFrequency: string; // e.g. "Daily", "Every 2 days"
}
