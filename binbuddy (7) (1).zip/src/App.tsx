/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import {
  Sparkles,
  User,
  ShieldCheck,
  Briefcase,
  Layers,
  MapPin,
  Compass,
  Mic,
  PlusCircle,
  Bell,
  Trash2,
  CheckCircle,
  Clock,
  Check,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  FileSpreadsheet,
  X,
  FileText,
  LogOut
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';

import { Complaint, UserProfile, UserRole, AIResult, LocationData } from './types';
import AIImageScanner from './components/AIImageScanner';
import InteractiveMap from './components/InteractiveMap';
import AIChatbot from './components/AIChatbot';
import LeaderboardQuiz from './components/LeaderboardQuiz';
import Login from './components/Login';

export default function App() {
  const [activeRole, setActiveRole] = useState<UserRole>('citizen');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotificationPanel, setShowNotificationPanel] = useState<boolean>(false);

  // Form State for reporting a new complaint
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [scannedAIResult, setScannedAIResult] = useState<AIResult | null>(null);
  const [voiceInputText, setVoiceInputText] = useState<string>('');
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [transcribedResult, setTranscribedResult] = useState<any>(null);
  const [textComplaint, setTextComplaint] = useState<string>('');
  const [isScanningActive, setIsScanningActive] = useState<boolean>(false);
  
  // Simulated Location Coordinates (Connaught Place New Delhi)
  const [detectedGPS, setDetectedGPS] = useState<LocationData | null>({
    lat: 28.6139,
    lng: 77.2090,
    address: 'Connaught Circle, Opposite Block B, Inner Ring Rd',
    city: 'New Delhi',
    state: 'Delhi',
    pincode: '110001',
  });

  const [selectedComplaintId, setSelectedComplaintId] = useState<string | null>(null);

  // Load profile from local storage on mount
  useEffect(() => {
    const savedUserStr = localStorage.getItem('binbuddy_user');
    if (savedUserStr) {
      try {
        const savedUser = JSON.parse(savedUserStr);
        setUserProfile(savedUser);
        setActiveRole(savedUser.role);
      } catch (err) {
        console.error(err);
      }
    }
  }, []);

  // Fetch initial profile & complaints
  useEffect(() => {
    if (userProfile) {
      fetchProfile();
      fetchComplaints();
      fetchAnalytics();
      fetchNotifications();
    }
  }, [activeRole, userProfile?.id]);

  const fetchProfile = async () => {
    if (!userProfile) return;
    try {
      const res = await fetch('/api/users');
      if (res.ok) {
        const usersList: UserProfile[] = await res.json();
        const updated = usersList.find(u => u.id === userProfile.id);
        if (updated) {
          setUserProfile(updated);
          localStorage.setItem('binbuddy_user', JSON.stringify(updated));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchComplaints = async () => {
    try {
      const res = await fetch('/api/complaints');
      const data = await res.json();
      setComplaints(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch('/api/analytics');
      const data = await res.json();
      setAnalytics(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/notifications');
      const data = await res.json();
      setNotifications(data);
    } catch (err) {
      console.error(err);
    }
  };

  // Simulate obtaining live geolocation using browser / random Connaught Place points
  const triggerGPSLocalization = () => {
    const latOffset = (Math.random() - 0.5) * 0.05;
    const lngOffset = (Math.random() - 0.5) * 0.05;
    const lat = 28.6139 + latOffset;
    const lng = 77.2090 + lngOffset;

    const addresses = [
      'Connaught Circle Outer Rail, near Block E, CP',
      'Janpath Rd Cross Lane, Sector 3',
      'Tolstoy Road Alleyway near Metro station',
      'Sansad Marg Outer Footpath crossing',
    ];
    const pickedAddress = addresses[Math.floor(Math.random() * addresses.length)];

    setDetectedGPS({
      lat,
      lng,
      address: pickedAddress,
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110001',
    });
  };

  // Translate/Transcribe Hindi speech simulation
  const triggerVoiceTranscribing = async () => {
    if (!voiceInputText.trim()) return;
    setIsTranscribing(true);
    try {
      const res = await fetch('/api/ai/voice-complaint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voiceTextPrompt: voiceInputText }),
      });
      const data = await res.json();
      setTranscribedResult(data);
      setTextComplaint(data.transcription);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTranscribing(false);
    }
  };

  // Submit complete complaint report
  const submitComplaint = async () => {
    if (!uploadedImage) {
      alert("Please upload/scan an image first.");
      return;
    }
    const reportPayload = {
      citizenId: userProfile?.id || 'citizen-1',
      citizenName: userProfile?.name || 'Rahul Sharma',
      image: uploadedImage,
      textComplaint: textComplaint || voiceInputText || 'Public rubbish debris',
      voiceComplaint: voiceInputText,
      location: detectedGPS,
      aiResult: scannedAIResult,
    };

    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportPayload),
      });
      if (res.ok) {
        // Reset states
        setUploadedImage(null);
        setScannedAIResult(null);
        setVoiceInputText('');
        setTranscribedResult(null);
        setTextComplaint('');
        
        fetchComplaints();
        fetchAnalytics();
        fetchNotifications();
        alert("Success! BinBuddy Smart complaint saved successfully!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Action flow - Assign, Start, Complete cleanup tasks
  const updateComplaintStatus = async (id: string, nextStatus: any) => {
    try {
      let body: any = { status: nextStatus };
      if (nextStatus === 'accepted') {
        body.assignedEmployeeId = 'employee-1';
        body.assignedEmployeeName = 'Amit Patel';
      }
      
      // Simulate Before/After photographs when completing
      if (nextStatus === 'verified') {
        body.afterImage = 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=400&q=80';
      }

      const res = await fetch(`/api/complaints/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        fetchComplaints();
        fetchAnalytics();
        fetchNotifications();
        if (userProfile) {
          fetchProfile();
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Mark all notifications as read
  const markNotificationsRead = async () => {
    try {
      await fetch('/api/notifications/read', { method: 'POST' });
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  // Export report dummy
  const exportReports = () => {
    alert("System Exporting! Complaints, coordinates, timestamps, and AI results exported to Excel format successfully.");
  };

  if (!userProfile) {
    return (
      <Login
        onLoginSuccess={(user) => {
          setUserProfile(user);
          setActiveRole(user.role);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/20 selection:text-emerald-300">
      {/* Top Banner Navigation Bar */}
      <header className="border-b border-zinc-900 bg-zinc-950/80 sticky top-0 backdrop-blur-md z-30 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-black font-extrabold shadow-md shadow-emerald-500/10">
              <span className="text-lg">B</span>
            </div>
            <div>
              <h1 className="text-base font-bold tracking-tight text-zinc-100 flex items-center gap-1.5">
                BinBuddy <Sparkles className="w-4 h-4 text-emerald-400 fill-emerald-400 animate-pulse" />
              </h1>
              <p className="text-[10px] text-zinc-400 font-medium">Smart AI Garbage Detection System</p>
            </div>
          </div>

          {/* Switch Roles Dashboard Picker */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-0.5 flex gap-1 items-center">
            <button
              onClick={() => setActiveRole('citizen')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeRole === 'citizen' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <User className="w-3.5 h-3.5" /> Citizen
            </button>
            <button
              onClick={() => setActiveRole('employee')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeRole === 'employee' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" /> Clean Crew
            </button>
            <button
              onClick={() => setActiveRole('admin')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeRole === 'admin' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" /> Admin Panel
            </button>
          </div>

          {/* Right hand utility buttons */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setShowNotificationPanel(!showNotificationPanel);
                markNotificationsRead();
              }}
              className="relative w-9 h-9 rounded-xl border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900 flex items-center justify-center text-zinc-400 hover:text-zinc-100 transition-all"
            >
              <Bell className="w-4 h-4" />
              {notifications.some(n => !n.read) && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 animate-ping" />
              )}
            </button>

            {userProfile && (
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2.5 bg-zinc-900/60 border border-zinc-800/85 pl-2.5 pr-3 py-1 rounded-full">
                  <img src={userProfile.avatar} className="w-6.5 h-6.5 rounded-full border border-zinc-850 object-cover" />
                  <div>
                    <p className="text-[10px] font-bold text-zinc-100 truncate max-w-[100px]">{userProfile.name}</p>
                    <p className="text-[9px] text-zinc-500 font-medium capitalize">{userProfile.role}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    localStorage.removeItem('binbuddy_user');
                    localStorage.removeItem('binbuddy_token');
                    setUserProfile(null);
                  }}
                  className="bg-zinc-900 border border-zinc-800 hover:border-red-500/30 text-zinc-400 hover:text-red-400 transition-all text-[11px] font-semibold px-2.5 py-1.5 rounded-xl flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" /> <span className="hidden xs:inline">Logout</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Real-time Notifications Popup Drawer */}
      {showNotificationPanel && (
        <div className="bg-zinc-900 border-b border-zinc-800 p-4 relative z-20">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Bell className="w-4 h-4 text-emerald-400" /> Notifications Stream
              </span>
              <button
                onClick={() => setShowNotificationPanel(false)}
                className="text-zinc-500 hover:text-zinc-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2 max-h-[140px] overflow-y-auto">
              {notifications.map((notif) => (
                <div key={notif.id} className="p-2 bg-zinc-950/60 rounded border border-zinc-850 flex justify-between items-center text-xs">
                  <div>
                    <strong className="text-zinc-200">{notif.title}</strong>
                    <p className="text-zinc-400 text-[11px] mt-0.5">{notif.body}</p>
                  </div>
                  <span className="text-[9px] text-zinc-500">
                    {new Date(notif.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Content Layout */}
      <main className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto space-y-6">

        {/* 1. CITIZEN ROLE VIEWPORT */}
        {activeRole === 'citizen' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Column 1: Scan & Add Voice complaint */}
            <div className="lg:col-span-1 space-y-5">
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
                <div className="flex items-center gap-1.5 border-b border-zinc-800/60 pb-3">
                  <PlusCircle className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-sm font-semibold text-zinc-200">New Garbage Incident Report</h3>
                </div>

                {/* AI Image Classification component link */}
                <AIImageScanner
                  onScanComplete={(image, result) => {
                    setUploadedImage(image);
                    setScannedAIResult(result);
                    setIsScanningActive(true);
                  }}
                  isLoading={isTranscribing}
                  setIsLoading={setIsTranscribing}
                />

                {/* Live GPS Auto Location card */}
                <div className="bg-zinc-950/50 rounded-xl p-3.5 border border-zinc-850/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" /> GPS Auto Location
                    </span>
                    <button
                      onClick={triggerGPSLocalization}
                      className="text-[10px] bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 px-2 py-0.5 rounded transition-all flex items-center gap-1"
                    >
                      <Compass className="w-3 h-3 text-emerald-400" /> Refresh GPS
                    </button>
                  </div>
                  {detectedGPS ? (
                    <div className="text-xs leading-normal">
                      <p className="text-zinc-200 font-medium truncate">{detectedGPS.address}</p>
                      <div className="flex gap-2 text-[10px] text-zinc-500 mt-1">
                        <span>Lat: {detectedGPS.lat.toFixed(4)}</span>
                        <span>Lng: {detectedGPS.lng.toFixed(4)}</span>
                        <span>Pincode: {detectedGPS.pincode}</span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[11px] text-zinc-500">Detecting satellite coordinates...</p>
                  )}
                </div>

                {/* Voice Complaint transcription block */}
                <div className="bg-zinc-950/50 rounded-xl p-3.5 border border-zinc-850/60 space-y-2">
                  <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                    <Mic className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> Voice Complaint (Hinglish/Hindi/English)
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={voiceInputText}
                      onChange={(e) => setVoiceInputText(e.target.value)}
                      placeholder='Say: "Yahan park ke paas bohot plastic hai"'
                      className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-zinc-200 focus:outline-none placeholder-zinc-600 focus:border-emerald-500/40"
                    />
                    <button
                      onClick={triggerVoiceTranscribing}
                      className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-black font-semibold text-xs px-3 py-1 rounded-lg transition-colors flex items-center gap-1"
                    >
                      Transcribe
                    </button>
                  </div>
                  {transcribedResult && (
                    <div className="bg-zinc-950 rounded p-2 text-[11px] border border-zinc-850 space-y-1">
                      <p className="text-zinc-400">
                        <strong className="text-zinc-200 font-semibold">Translated English:</strong>{' '}
                        {transcribedResult.transcription}
                      </p>
                      <p className="text-zinc-400">
                        <strong className="text-zinc-200 font-semibold">Hindi Verification:</strong>{' '}
                        {transcribedResult.hindiTranslation}
                      </p>
                    </div>
                  )}
                </div>

                <button
                  onClick={submitComplaint}
                  disabled={!uploadedImage}
                  className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-black font-bold py-2 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all disabled:opacity-40"
                >
                  Save & Report BinBuddy complaint
                </button>
              </div>
            </div>

            {/* Column 2 & 3: Interactive Map and Wallet activities */}
            <div className="lg:col-span-2 space-y-6">
              {/* Map */}
              <InteractiveMap
                complaints={complaints}
                activeRole={activeRole}
                selectedComplaintId={selectedComplaintId}
                onSelectComplaint={(c) => setSelectedComplaintId(c.id)}
              />

              {/* Quiz / Wallet Activities */}
              <LeaderboardQuiz
                userPoints={userProfile?.rewardPoints || 0}
                onPointsRedeemed={(deducted, title) => {
                  fetchProfile();
                }}
              />
            </div>
          </div>
        )}

        {/* 2. CLEANING EMPLOYEE WORKPORT */}
        {activeRole === 'employee' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left column: Tasks list */}
            <div className="lg:col-span-1 space-y-5">
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-800/60 pb-3">
                  <div className="flex items-center gap-1.5">
                    <Briefcase className="w-5 h-5 text-emerald-400" />
                    <h3 className="text-sm font-semibold text-zinc-200">Assigned Cleanup Tasks</h3>
                  </div>
                  <span className="text-xs bg-zinc-950 px-2 py-0.5 rounded text-emerald-400 font-bold">
                    Amit Patel (ID: employee-1)
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[400px] overflow-y-auto">
                  {complaints
                    .filter((c) => c.status === 'assigned' || c.status === 'accepted' || c.status === 'in_progress')
                    .map((comp) => (
                      <div
                        key={comp.id}
                        onClick={() => setSelectedComplaintId(comp.id)}
                        className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all space-y-2 ${
                          selectedComplaintId === comp.id
                            ? 'border-emerald-500 bg-zinc-950'
                            : 'border-zinc-800 bg-zinc-900/40 hover:bg-zinc-900'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-zinc-400">{comp.id}</span>
                          <span className="text-[9px] font-semibold tracking-wider bg-amber-950 text-amber-400 px-2 py-0.5 rounded">
                            {comp.status.toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-200 truncate">{comp.location.address}</p>
                          <p className="text-[10px] text-zinc-500 mt-0.5">Reported: {new Date(comp.timestamp).toLocaleDateString()}</p>
                        </div>
                        <div className="flex items-center justify-between pt-1 text-[11px]">
                          <span className="text-emerald-400 font-medium capitalize">
                            {comp.aiResult?.wasteType || 'general'} waste detected
                          </span>
                          <span className="text-zinc-400 flex items-center gap-1">
                            <ArrowRight className="w-3 h-3" /> Select task
                          </span>
                        </div>
                      </div>
                    ))}
                  {complaints.filter((c) => c.status === 'assigned' || c.status === 'accepted' || c.status === 'in_progress').length === 0 && (
                    <div className="text-center py-8 text-zinc-500">
                      <CheckCircle className="w-8 h-8 mx-auto mb-1.5 text-zinc-700" />
                      <p className="text-xs font-semibold">Zero pending tasks today!</p>
                      <p className="text-[10px] text-zinc-600 mt-0.5">Municipal clean area achieved.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Map and details block */}
            <div className="lg:col-span-2 space-y-6">
              <InteractiveMap
                complaints={complaints}
                activeRole={activeRole}
                selectedComplaintId={selectedComplaintId}
                onSelectComplaint={(c) => setSelectedComplaintId(c.id)}
                onUpdateComplaintStatus={updateComplaintStatus}
              />

              {/* Task proof and detail container */}
              {selectedComplaintId && complaints.find((c) => c.id === selectedComplaintId) && (
                (() => {
                  const comp = complaints.find((c) => c.id === selectedComplaintId)!;
                  return (
                    <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
                      <div className="flex items-center justify-between border-b border-zinc-800/60 pb-3">
                        <h4 className="text-sm font-semibold text-zinc-200">Litter Detail Board ({comp.id})</h4>
                        <span className="text-xs text-zinc-400">{comp.location.address}</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1.5">Litter Evidence</p>
                          <img src={comp.image} className="w-full aspect-video rounded-lg object-cover border border-zinc-800" />
                        </div>
                        <div className="text-xs space-y-1">
                          <p className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">Incident Profile</p>
                          <p><strong className="text-zinc-300">Citizen Reporter:</strong> {comp.citizenName}</p>
                          <p><strong className="text-zinc-300">Category:</strong> <span className="capitalize">{comp.aiResult?.wasteType || 'General'}</span></p>
                          <p><strong className="text-zinc-300">AI Confidence:</strong> {comp.aiResult ? `${Math.round(comp.aiResult.confidence * 100)}%` : 'Manual classification'}</p>
                          <p><strong className="text-zinc-300">Trash Volume:</strong> {comp.aiResult?.quantity || 'Unmeasured'}</p>
                        </div>
                        <div className="flex flex-col justify-center space-y-2">
                          <p className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">Status Workflow Controls</p>
                          {comp.status === 'assigned' && (
                            <button
                              onClick={() => updateComplaintStatus(comp.id, 'accepted')}
                              className="bg-amber-500 hover:bg-amber-600 active:scale-95 text-black font-semibold text-xs py-1.5 px-3 rounded-lg transition-all"
                            >
                              Accept Task
                            </button>
                          )}
                          {comp.status === 'accepted' && (
                            <button
                              onClick={() => updateComplaintStatus(comp.id, 'in_progress')}
                              className="bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-semibold text-xs py-1.5 px-3 rounded-lg transition-all"
                            >
                              Start Cleanup (GPS Tracked)
                            </button>
                          )}
                          {comp.status === 'in_progress' && (
                            <button
                              onClick={() => updateComplaintStatus(comp.id, 'verified')}
                              className="bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-black font-bold text-xs py-1.5 px-3 rounded-lg transition-all flex items-center justify-center gap-1"
                            >
                              <Check className="w-3.5 h-3.5" /> Upload proof & Mark Cleaned
                            </button>
                          )}
                          {comp.status === 'verified' && (
                            <div className="text-center py-2 bg-emerald-950/20 text-emerald-400 border border-emerald-900/30 rounded-lg text-[11px] font-medium">
                              ✓ Cleanup verified by citizen and points dispersed.
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()
              )}
            </div>
          </div>
        )}

        {/* 3. MUNICIPALITY ADMIN CENTRAL DASHBOARD */}
        {activeRole === 'admin' && (
          <div className="space-y-6">
            
            {/* Top row stats */}
            {analytics && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-md">
                  <p className="text-xs text-zinc-500 font-medium">Active Incidents</p>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="text-2xl font-bold text-zinc-100">{analytics.generalStats.pendingComplaints}</span>
                    <span className="text-[10px] text-red-400 flex items-center gap-0.5"><AlertCircle className="w-3 h-3" /> Pending crew</span>
                  </div>
                </div>
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-md">
                  <p className="text-xs text-zinc-500 font-medium">Completed Cleanups</p>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="text-2xl font-bold text-zinc-100">{analytics.generalStats.completedComplaints}</span>
                    <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">✓ 100% verified</span>
                  </div>
                </div>
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-md">
                  <p className="text-xs text-zinc-500 font-medium">Active Crew Members</p>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="text-2xl font-bold text-zinc-100">{analytics.generalStats.activeEmployees}</span>
                    <span className="text-[10px] text-zinc-400">Green Sweepers</span>
                  </div>
                </div>
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-md">
                  <p className="text-xs text-zinc-500 font-medium">Daily Inflow Rate</p>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="text-2xl font-bold text-zinc-100">+{analytics.generalStats.todayComplaints}</span>
                    <span className="text-[10px] text-zinc-500">complaints reported</span>
                  </div>
                </div>
              </div>
            )}

            {/* Interactive map representing full municipal view */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Map Column */}
              <div className="lg:col-span-2 space-y-6">
                <InteractiveMap
                  complaints={complaints}
                  activeRole={activeRole}
                  selectedComplaintId={selectedComplaintId}
                  onSelectComplaint={(c) => setSelectedComplaintId(c.id)}
                />

                {/* Live verification list container */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
                  <div className="flex items-center justify-between border-b border-zinc-800/60 pb-3">
                    <h3 className="text-sm font-semibold text-zinc-200">Incident Triage Queue</h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={exportReports}
                        className="text-xs bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 px-2.5 py-1 rounded flex items-center gap-1 transition-all"
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Export Reports
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-800 text-zinc-500 font-semibold">
                          <th className="pb-2.5">ID</th>
                          <th className="pb-2.5">Citizen</th>
                          <th className="pb-2.5">Waste Type</th>
                          <th className="pb-2.5">Address</th>
                          <th className="pb-2.5">Triage Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-850">
                        {complaints.map((comp) => (
                          <tr key={comp.id} className="hover:bg-zinc-950/20 transition-colors">
                            <td className="py-3 font-semibold text-zinc-400">{comp.id}</td>
                            <td className="py-3 text-zinc-300">{comp.citizenName}</td>
                            <td className="py-3">
                              <span className="capitalize bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800/80 text-emerald-400 font-medium">
                                {comp.aiResult?.wasteType || 'General'}
                              </span>
                            </td>
                            <td className="py-3 text-zinc-400 truncate max-w-[150px]">{comp.location.address}</td>
                            <td className="py-3 flex gap-2">
                              {comp.status === 'pending' && (
                                <button
                                  onClick={() => updateComplaintStatus(comp.id, 'assigned')}
                                  className="bg-emerald-600 hover:bg-emerald-700 text-black font-semibold px-2 py-1 rounded text-[10px] transition-colors"
                                >
                                  Dispatch Crew
                                </button>
                              )}
                              <button
                                onClick={async () => {
                                  await fetch(`/api/complaints/${comp.id}`, { method: 'DELETE' });
                                  fetchComplaints();
                                  fetchAnalytics();
                                }}
                                className="text-red-400 hover:text-red-300 hover:bg-red-950/20 px-2 py-1 rounded transition-all"
                                title="Reject Report"
                              >
                                Reject
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Graphical Visualizations Analytics Panel */}
              <div className="lg:col-span-1 space-y-6">
                
                {/* Waste Distribution pie chart */}
                {analytics && (
                  <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
                    <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                      Litter Types Distribution (AI)
                    </p>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={analytics.wasteDistribution}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={75}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {analytics.wasteDistribution.map((entry: any, index: number) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#fff' }} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-400">
                      {analytics.wasteDistribution.map((entry: any) => (
                        <div key={entry.name} className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                          <span>{entry.name}: {entry.value}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* AI Pollution Hotspots Predictions list */}
                {analytics && (
                  <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                      <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                        AI Pollution Hotspots Forecast
                      </p>
                    </div>
                    <div className="space-y-3">
                      {analytics.predictions.map((pred: any) => (
                        <div key={pred.areaName} className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-850 space-y-2 text-xs">
                          <div className="flex justify-between items-center">
                            <strong className="text-zinc-200 truncate pr-2 max-w-[130px]">{pred.areaName}</strong>
                            <span className="text-[10px] text-red-400 font-semibold bg-red-950/20 border border-red-900/20 rounded px-1.5 py-0.5">
                              Next: {pred.predictedPollutionNextWeek}%
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-zinc-400">
                            <span>Main waste: <strong className="text-emerald-400 capitalize">{pred.mostCommonWasteType}</strong></span>
                            <span>Visit frequency: {pred.recommendedFrequency}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Floating Chat assistant widget trigger */}
      <section className="fixed bottom-4 left-4 z-40 max-w-sm w-[90%] md:w-[350px]">
        <details className="group bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
          <summary className="list-none cursor-pointer p-3.5 bg-emerald-500 hover:bg-emerald-600 text-black font-bold text-xs flex items-center justify-between transition-colors">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 fill-black text-black" /> Ask BinBuddy AI Chatbot
            </span>
            <span className="text-[10px] bg-black/15 text-black px-2 py-0.5 rounded transition-all group-open:rotate-180">
              Open Chat
            </span>
          </summary>
          <div className="border-t border-zinc-800">
            <AIChatbot />
          </div>
        </details>
      </section>

      {/* Footer credits bar */}
      <footer className="bg-zinc-950 border-t border-zinc-900 py-6 text-center text-xs text-zinc-500 font-medium">
        <p>© {new Date().getFullYear()} BinBuddy Systems. Clean Environment via Artificial Intelligence.</p>
        <p className="text-[10px] text-zinc-600 mt-1">Swachh Bharat Integrated Partner. Delhi NCR Sector Triage.</p>
      </footer>
    </div>
  );
}
